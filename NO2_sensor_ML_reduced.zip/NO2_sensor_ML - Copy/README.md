# NO2 sensor ML: humidity and temperature effects on the response

Machine-learning estimate of how humidity and temperature change the NO₂ response of the Au@MoS₂ nanowire sensor in the
manuscript. The models are trained on published humidity and temperature sweeps of **other** MoS₂-based NO₂ sensors,
learn how a response changes along a sweep, and apply that change to the sensor's measured response (42.59% at 50 ppm
NO₂, 520 nm light). Everything, from the input readings to the Excel tables and figures, is produced by the code in this
folder and can be rerun with one command.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt                         # Python 3.13, pinned versions
python run_all.py                                       # about 45 minutes on 2 CPU cores; writes results/
python tests/check_reproduction.py                      # confirms the run matches the reference results
```

Or open `notebooks/NO2_ML_analysis.ipynb` in Jupyter (`pip install jupyterlab`, then `jupyter lab`) and run all cells:
it goes through the same steps one at a time and shows the tables and figures as it goes.

**You do not need to run anything to see the results:** `results/` already holds the output of the reference run, and
the notebook is saved with its outputs.

## Folder structure

```
NO2_sensor_ML/
├── README.md                       this file
├── requirements.txt                pinned package versions (environment.yml for conda)
├── run_all.py                      runs the whole analysis from the command line
├── notebooks/
│   └── NO2_ML_analysis.ipynb       the same analysis step by step, saved with outputs
├── no2ml/                          the code (a small Python package)
│   ├── config.py                   every setting: rows, seeds, tests, excluded papers, paper model, anchor
│   ├── data.py                     read the input Excel, unify responses, build curves, interpolate to 100 rows
│   ├── models.py                   training rows (all pairs / from lowest point) and the 7 models
│   ├── evaluate.py                 hold-out tests, error summaries, R² and RMSE, choice of the paper model
│   ├── predict.py                  predictions for your sensor, leave-one-paper-out check
│   ├── pipeline.py                 runs a dataset / everything
│   ├── tables.py                   tidy result tables
│   ├── excel.py, figures.py        Excel workbooks (with charts) and figures
│   ├── outputs.py                  writes results/
│   └── check.py                    compares a run with the reference
├── data/
│   ├── NO2_sensor_data.xlsx        THE INPUT: every reading, one table per sheet (see data/README.md)
│   ├── raw/                        the dataset workbooks as received and after checking, local-baseline values
│   └── source_papers/              place for the source PDFs (not included; list inside)
├── scripts/
│   └── build_input_workbook.py     rebuilds data/NO2_sensor_data.xlsx from data/raw
├── results/                        everything a run writes (reference run included)
│   ├── excel/NO2_ML_datasets_and_tests.xlsx
│   ├── excel/NO2_ML_paper_R2_RMSE.xlsx
│   ├── figures/                    response curves and parity plots, PNG (300 dpi) and PDF
│   ├── csv/tables/                 every Excel table as CSV
│   ├── csv/raw/                    per-seed predictions and other raw outputs
│   └── run_info.json               settings, software versions, run time, chosen models
├── tests/
│   ├── check_reproduction.py       compare results/ with the reference
│   └── expected/                   reference tables from the original run
├── docs/
│   └── METHODS.md                  exactly what the code does, with suggested wording for the manuscript
└── legacy/                         the two original scripts the project started from
```

## What the outputs hold

Every sheet is one table with its header in row 1 (no merged cells, no notes under tables), so people can read the
workbooks in Excel and code can read them with `pandas.read_excel(path, sheet_name=...)`. The same tables are in
`results/csv/tables/`.

**`NO2_ML_datasets_and_tests.xlsx`**: `README`; `summary` (best model per dataset and test); `dataset_humidity`,
`dataset_temperature`, `dataset_temperature_local` (the 100-row training data, interpolated rows in grey); `curves`;
`models` (settings); `holdout_results` (every test, training form and model, measured-only and 100 rows);
`holdout_per_sensor`; `predictions_your_sensor`.

**`NO2_ML_paper_R2_RMSE.xlsx`**: `README`; `metrics` (R² and RMSE of every configuration, paper model in blue, baseline
in grey); `chart_data` and `charts` (bar charts of R² and RMSE); `parity_humidity`, `parity_temperature` (held-out points
of the paper model, with chart); `curve_humidity`, `curve_temperature` (your sensor's predicted response, every
configuration, with chart); `robustness_tests` (hide one paper vs hide one lab); `robustness_leave_one_out`;
`chart_helpers`.

**Figures**: `humidity_vs_response`, `temperature_vs_response`, `parity_humidity`, `parity_temperature`.

## Main results (default settings)

Hold-out tests on the 100-row datasets; error = median miss on the hidden measured points.

| dataset | test | no-change error | best model (error) | models beating no change |
|---|---|---|---|---|
| humidity | hide one paper | 11.9% | Gaussian process, from lowest point (8.4%) | 1 of 12 |
| humidity | hide one lab | 11.9% | random forest, all pairs (18.2%) | 0 of 12 |
| humidity | hide one sensor | 11.9% | gradient boosting, all pairs (18.9%) | 0 of 12 |
| temperature | hide one paper | 72.4% | support vector regression, all pairs (40.1%) | 10 of 10 |
| temperature | hide one lab | 72.4% | neural network, from lowest point (37.5%) | 10 of 10 |
| temperature | hide one sensor | 72.4% | support vector regression, all pairs (34.2%) | 10 of 10 |
| temperature_local | hide one paper | 47.7% | support vector regression, from lowest point (47.8%) | 0 of 10 |

Paper models (lowest error in the hide-one-paper test), R² and RMSE on held-out papers:

| factor | model | R², response | RMSE (% points) | R², change | median miss | hide one lab |
|---|---|---|---|---|---|---|
| humidity | Gaussian process, from lowest point | 0.97 (no change 0.95) | 8.8 (11.0) | −0.24 (−0.44) | 8.4% (11.9%) | 44.3% (11.9%) |
| temperature | support vector regression, all pairs | 0.74 (0.37) | 20.1 (31.5) | 0.20 (−0.48) | 40.1% (72.4%) | 58.2% (72.4%) |

Predicted response of your sensor (starting from 42.59% at 20% RH and 300 K):

* humidity: 39.7% at 30% RH, 31.2% at 50% RH, 24.8% at 60% RH, 12.9% at 80% RH, 9.3% at 90% RH
* temperature: 32.1% at 333 K, 26.0% at 373 K, 15.9% at 400 K

**How far to trust them.** Temperature: the models beat the no-change baseline in every test, and the 373 K value stays
between 24.7% and 27.1% whichever training paper is left out. Humidity: only one configuration beats no change, and only
when single papers are hidden. Hidden lab by lab, no humidity model beats no change, and the humidity curve rests mainly on
one paper: without Kumar 2025 its 80% RH value is 38.0% instead of 12.9%. Treat it as a general indication that the
response falls at high humidity, not as a validated prediction. See `robustness_tests` and `robustness_leave_one_out`.

## Changing the analysis

Every choice is a setting in `no2ml/config.py` (`Settings`). Change it in the notebook's settings cell, or on the command
line:

| what | command line | default |
|---|---|---|
| keep Chen 2021 in the humidity data | `--exclude-humidity` (no names) | Chen 2021 left out |
| leave out other papers | `--exclude-humidity "Hu 2023"`, `--exclude-temperature "Kumar 2019 (IEEE Sens. J.)"` | none |
| report a chosen model | `--humidity-model "all pairs\|Support vector regression"` | lowest hide-one-paper error |
| rows after interpolation | `--n-total 0` (measured points only) | 100 |
| tests | `--tests paper lab` | paper lab sensor |
| datasets | `--datasets humidity temperature` | all three |
| quick check of the code | `--quick` (2 seeds, paper test only; numbers differ) | |
| output folder | `--out my_results` | results |

With other settings the run writes to `results/` as usual; `tests/check_reproduction.py` then reports differences,
which is expected.

## Reproducibility

* Pinned versions in `requirements.txt` (Python 3.13). The random models use seeds 0–9 and the Gaussian process a fixed
  optimizer seed, so the numbers repeat exactly; the only run-to-run differences are about 1e-15, from the order in which
  random-forest trees are summed in parallel.
* `tests/expected/` holds the tables of the reference run made with `run_all.py`. The notebook was then run from
  scratch and its results matched the reference (last cell of the notebook).
* The code was checked against the earlier, separately written scripts of this project: it reproduces their hold-out
  results, datasets, held-out predictions and sensor curves exactly, with and without Chen 2021. With `n_total = 0` and
  Chen 2021 kept, it also reproduces the set-B results of both original scripts in `legacy/` exactly.
* With other versions of numpy or scikit-learn, small differences can appear (mostly in the neural network and the
  Gaussian process); `tests/check_reproduction.py` shows where and how large.

## Caveats to state in the manuscript

* The training data are other groups' sensors (5 papers for humidity, 5 for temperature); nothing about your sensor is
  used in training. All temperature sweeps were measured in the dark; four of the six temperature sensors come from one
  laboratory.
* Interpolated rows are not measurements: humidity has 25 measured and 75 interpolated rows, temperature 58 and 42.
* Your point is placed at 20% RH (from the manuscript's old ML section; the Methods say only "ambient") and 300 K.
* Chen 2021 is left out of humidity: its responses (500–850%) are 15–20 times yours and its rise with humidity reflects a
  drifting baseline.
* The no-change baseline already scores a high R² on response values because the sensors differ greatly in size; report
  R² of the change alongside.

Details of every step: `docs/METHODS.md`. Data provenance: `data/README.md`.
