# Data

| file | what it is |
|---|---|
| `NO2_sensor_data.xlsx` | **The input of the pipeline.** One table per sheet, header in row 1: `humidity`, `temperature`, `your_sensor`, `sources`, `conversions`, `columns`, `README`. Built by `python scripts/build_input_workbook.py` from the files in `raw/`. |
| `raw/NO2_humidity_temperature_datasets_as_received.xlsx` | The dataset workbook as first delivered (with live formulas and the original ML results). |
| `raw/NO2_humidity_temperature_datasets_checked.xlsx` | The same after the independent check: `verified` and `check_note` columns, corrected check list, a `verification` sheet. Readings are unchanged. |
| `raw/kumar2018_local_baselines.csv` | Local-baseline values for 14 Kumar 2018 (Nanotechnology) pulses, used by the `temperature_local` dataset. |
| `source_papers/` | Put the source PDFs here if you want them with the project (not included). |

To correct a reading, edit `NO2_sensor_data.xlsx` (Ra, Rg or published_value, and response_pct to match, or clear
response_pct), or edit the raw workbook and rebuild with `scripts/build_input_workbook.py`. The code recomputes every
response and stops if a stored response disagrees with its reading.
