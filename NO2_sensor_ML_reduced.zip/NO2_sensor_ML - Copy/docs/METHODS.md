# Methods

This file describes exactly what the code in `no2ml/` does, in the order it does it, so the analysis can be described in a
manuscript and repeated by someone else. Default settings are in `no2ml/config.py`.

## 1. Data

**Source.** `data/NO2_sensor_data.xlsx`, built by `scripts/build_input_workbook.py` from the raw workbooks in `data/raw/`.
Each row is one published reading of one MoS₂-based NO₂ sensor under stated conditions, taken from a figure, table or the
text of the paper named in `paper` (references and DOIs in the `sources` sheet). In an independent check every reading
was re-read from the source PDFs (`verified`, `check_note` columns); all agree within the stated reading uncertainty except
three Kumar 2019 values that come from a thesis table and supporting information not available to the check.

**Unified response.** Every reading is converted to S (%) = (higher resistance / lower resistance − 1) × 100 by one of five
rules (`conversions` sheet):

| conversion | reading | S (%) |
|---|---|---|
| from Ra and Rg | baseline Ra and resistance in gas Rg | (max(Ra, Rg) / min(Ra, Rg) − 1) × 100 |
| ratio | Rg/Ra or Ra/Rg (> 1) | (value − 1) × 100 |
| percent (resistance falls) | (Ra − Rg)/Ra × 100 | value / (100 − value) × 100 |
| fraction | (Rg − Ra)/Ra | value × 100 |
| as published | (Rg − Ra)/Ra × 100, resistance rising | value |

**Curves.** A curve is one sensor measured at several humidities (or temperatures) with everything else fixed.
Humidity: `device_id` + `series` (one figure panel). Temperature: `device_id` + `NO2_ppm`; at least 2 points.
Only rows with `use_in_model = 1` are used.

**Exclusions in this analysis** (`Settings.exclude_papers`). Humidity: Chen 2021 (two curves). Its light-on responses
(500–850%) are 15–20 times the target sensor's, and the rise of that curve with humidity reflects a drifting baseline
(the paper describes the response as steady). Temperature: none (Kumar 2019 is kept although its resistance falls in NO₂
and it did not recover at 25 °C).

**Datasets.**

| dataset | factor | curves | papers | measured points |
|---|---|---|---|---|
| humidity | relative humidity | 6 | 5 | 25 |
| temperature | temperature, values as delivered | 16 | 5 | 58 |
| temperature_local | temperature, 14 Kumar 2018 (Nanotechnology) pulses measured from their local baseline | 16 | 5 | 58 |

The local-baseline values are ((1 + v/100) / (1 + b/100) − 1) × 100, where v is the delivered value and b the unrecovered
response before the pulse, read from the thesis (Fig. 3.6a/b, approximate).

## 2. Padding to 100 rows by interpolation

Points are added only inside each curve's measured range until a dataset has 100 rows. Each new point goes into the gap
with the largest width / (points already in it + 1), over all curves; ties go to the curve with the fewest new points so far,
then to the earlier gap. A gap that receives k points is split into k + 1 equal steps. The response of a new point is read
off the straight line in log10(response) between the two measured neighbours. Default result: humidity 25 measured +
75 interpolated (spacing 4–5% RH); temperature 58 measured + 42 interpolated (spacing 12.5–20 °C).
**Interpolated rows are not measurements and add no information beyond the measured points.** They are used for training
only, never for testing.

## 3. Learning task

Input: the starting value and the new value of RH (or T), each divided by 100. Output: the change
log10(S at the new value / S at the starting value) along a curve. A prediction for any sensor is its measured response
× 10^(predicted change). The models never compare responses across sensors, so sensor size does not enter.

**Training forms.**
*all pairs*: every ordered pair (i, j), i ≠ j, of points within a curve; the model is made antisymmetric,
f(a, b) = (g(a, b) − g(b, a)) / 2.
*from lowest point*: the pairs (lowest point, j) for every point j of a curve, including j = lowest (zero change).

**Weights.** Humidity, all pairs: every curve carries equal total weight (1 / number of pairs per row). Humidity, from
lowest point: weight 1 per row. Temperature: every sensor carries equal weight, split equally over its curves and then over
the rows of each curve. Weights are rescaled to average 1.

## 4. Models

Settings are unchanged from the original scripts (`legacy/`). Random models are fitted once per seed (seeds 0–9).

| model | settings |
|---|---|
| No change (baseline) | predicts zero change |
| Random forest | 300 trees, min_samples_leaf 2 |
| Gradient boosting | 200 trees, learning rate 0.05, depth 2, min_samples_leaf 2, subsample 0.8 |
| Gradient boosting, monotonic (humidity only) | histogram boosting, 200 iterations, learning rate 0.05, depth 2, response may only fall as RH rises |
| Gaussian process | constant × RBF kernel, length scale 0.3 (humidity) or 0.5 (temperature), noise 4e-4 / weight, 3 optimizer restarts |
| Support vector regression | RBF kernel, C 1, epsilon 0.005, gamma 2 |
| Neural network | 8 tanh hidden units, L-BFGS, alpha 1e-3, up to 5000 iterations |

## 5. Hold-out tests

* **hide one paper** (the fair test): every paper in turn is removed from training and its curves are predicted.
* **hide one lab**: all papers of one institution are removed together (for humidity, Hu 2023 and Hu 2025 share a lab).
* **hide one sensor**: one sensor (temperature) or one curve (humidity) at a time.

Each hidden curve is predicted from its own lowest measured point; only measured points are scored. The tests are run
twice: with the measured points only and with the 100-row datasets.

**Error per point** = (larger / smaller − 1) × 100 between predicted and measured response
= 100 × (10^|predicted change − measured change| − 1).
**error_pct** = median over all hidden points (for random models, the median over seeds of the per-seed median).
**R2_of_change** = 1 − Σ(true − predicted change)² / Σ(true change − mean true change)², over all hidden points
(median over seeds).

## 6. R² and RMSE for the paper

From the hide-one-paper test of the 100-row datasets, using at each hidden measured point the median prediction over seeds:

* response values: R² and RMSE (percentage points) between predicted and measured S (%);
* change: R² and RMSE of log10(S / S_start);
* median miss (%), as in section 5.

The no-change baseline is always reported alongside. Because the sensors' responses differ by about 100-fold (humidity)
or more, the baseline already reaches a high R² on response values; R² of the change is the scale-free measure of skill.

**Paper model.** For each factor, the configuration (training form × model) with the lowest error_pct in the
hide-one-paper test of the 100-row dataset, unless set in `Settings.paper_model`.

## 7. Predictions for the target sensor

Every configuration is trained on all curves of the 100-row dataset and predicts the change from the target sensor's
measured point, 42.59% at 50 ppm NO₂ under 520 nm light (manuscript Fig. 3c), placed at 20% RH and 27 °C (300 K).
The 20% RH placement comes from the manuscript's earlier ML section; the Methods state only "ambient" humidity.
Predictions are given on a coarse grid (median, lowest and highest over seeds) and a 1-unit fine grid (median over seeds).
The shaded band in the figures spans all configurations except those in `Settings.band_exclude` (default: the all-pairs
Gaussian process for humidity, whose fit is numerically unstable).

## 8. Robustness checks

* **Paper vs lab**: error and R² of change of every configuration in the hide-one-paper and hide-one-lab tests.
* **Leave one paper out**: the target sensor's prediction refitted with each training paper removed in turn, for the
  paper model and the all-pairs random forest and gradient boosting.

## 9. Software and reproducibility

Python 3.13 with numpy 2.5.3, pandas 3.0.5, scikit-learn 1.9.1, scipy 1.18.1 (pinned in `requirements.txt`). Every random
model uses fixed seeds and the Gaussian process uses a fixed optimizer seed, so a run with these versions reproduces the
stored reference (`tests/expected`) exactly, apart from differences of about 1e-15 from the order in which random forest
trees are summed in parallel. With the default settings the code reproduces the results delivered earlier in this
project, and with `n_total = 0` and Chen 2021 included it reproduces the set-B results of the original scripts.

## Suggested wording (adapt as needed)

> To estimate how humidity and temperature affect the response of our sensor, we trained regression models on published
> humidity and temperature sweeps of other MoS₂-based NO₂ sensors (5 papers each; Table Sx). All readings were converted to
> S = (R_high/R_low − 1) × 100. The models learn the change in log10(S) between two humidities (or temperatures) along a
> curve and were applied to our measured response at 50 ppm NO₂. To regularise training, each dataset was padded to 100
> rows by log-linear interpolation within each measured curve; interpolated points were used for training only.
> Models were evaluated by leave-one-paper-out cross-validation on measured points only and compared with a no-change
> baseline.
