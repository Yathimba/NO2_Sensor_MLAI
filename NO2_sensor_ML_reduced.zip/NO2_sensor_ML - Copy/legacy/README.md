# Original scripts

`humidity_ml.py` and `temperature_ml.py` are the scripts that produced the ML results in the original dataset workbook
(`data/raw/NO2_humidity_temperature_datasets_as_received.xlsx`, sheets ML_humidity_B, ML_temperature_B and ML_set_A_check).
They read the raw workbook directly:

    python legacy/humidity_ml.py data/raw/NO2_humidity_temperature_datasets_as_received.xlsx      (about 15 minutes)
    python legacy/temperature_ml.py data/raw/NO2_humidity_temperature_datasets_as_received.xlsx   (about 6 minutes)

They are kept for provenance and are not used by the pipeline. The `no2ml` package uses the same data rules, curves,
training rows, models and seeds. Run with `n_total = 0`, no papers excluded and the sensor and paper tests, it gives the
same set-B results as these scripts. Two things exist only here: the narrower set A (a sensitivity check) and an older
interpolation (17 evenly spaced points per humidity curve), which the 100-row padding replaces.
