"""Humidity-only machine-learning models for the NO2 response (set B = every humidity curve in the workbook).

Usage:  python humidity_ml.py NO2_humidity_temperature_datasets.xlsx        (about 15 minutes on 2 cores)
        python humidity_ml.py NO2_humidity_temperature_datasets.xlsx B      (set B only)
Needs:  numpy, pandas, scikit-learn, openpyxl  (run with Python 3.13, scikit-learn 1.9.1, numpy 2.5.3, pandas 3.0.5)

DATA      Sheet 'humidity_B', rows with use_in_model = 1. One curve = one sensor in one figure (device_id + series),
          measured at several humidities with everything else fixed.
          Set B (the chosen set): every curve.  Set A (sensitivity check only): every curve except Chen 2021 and Li 2026.
          The unified response (column response_pct) is recomputed here from the input cells with the same five rules
          as the workbook formula; the script stops if the two disagree.
TASK      Predict how the response changes when humidity changes.
          input  = humidity at the starting point (h0) and at the new point (h1), as fractions (0.20 = 20% RH)
          output = log10(response at h1 / response at h0)
TRAINING  'all pairs'          every ordered pair of points within a curve; the model is made antisymmetric
                               (the change 30->70% RH is minus the change 70->30% RH); each curve carries equal weight
          'from lowest point'  only rows that start at the curve's lowest humidity (the same form as the test), weight 1 each
          'measured'           the published points only
          '+ interpolated'     straight lines between neighbouring measured points (log scale), read at evenly spaced
                               humidities inside each curve's range (17 per curve, 16 for Hu 2025). Not measurements.
TESTS     'hide one sensor'    train on the other curves, predict the hidden curve's points from its own lowest point.
          'hide one paper'     hide every curve of a paper together (the fair test: Chen 2021's dark and 530 nm curves
                               are the same device, and Li 2026's two sensors share a laboratory and set-up).
          Error per point = (larger / smaller - 1) x 100. Reported: median error over all hidden points, its range over
          10 random seeds, worst point, per-curve median, R2 of the predicted change (log scale) and, to show why it
          misleads, R2 of the response values themselves.
OUTPUT    humidity_ml_results.csv, humidity_ml_predictions_your_sensor.csv, humidity_ml_training_rows.csv
"""
import sys, itertools, warnings, time
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, HistGradientBoostingRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, RBF
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
warnings.filterwarnings('ignore')

TABLE = sys.argv[1] if len(sys.argv) > 1 else 'NO2_humidity_temperature_datasets.xlsx'
ONLY = sys.argv[2] if len(sys.argv) > 2 else None
SETS = {'B: every humidity curve': [], 'A: check, without Chen 2021 and Li 2026': ['Chen 2021', 'Li 2026']}
ANCHOR = dict(response=42.59, RH=20)       # your 50 ppm, light-on value; 20% RH from manuscript section 3.7
GRID = [20, 30, 40, 50, 60, 70, 80, 90]
SEEDS = list(range(10))
N_INTERP = {'Hu2025_AuMoS2SnS': 16}        # interpolated rows per curve; 17 otherwise

# ------------------------------------------------------------------ data
def unified(r):
    """Same five rules as the response_pct formula in the workbook."""
    c, v = r.conversion, r.published_value
    if c == 'from Ra and Rg': return (max(r.Ra, r.Rg) / min(r.Ra, r.Rg) - 1) * 100
    if c == 'ratio': return (v - 1) * 100
    if c == 'percent (resistance falls)': return v / (100 - v) * 100
    if c == 'fraction': return v * 100
    if c == 'as published': return v
    raise ValueError(f'row {r.row_id}: unknown conversion {c!r}')

df = pd.read_excel(TABLE, sheet_name='humidity_B')
df = df[df.row_id.notna()]
calc = df.apply(unified, axis=1)
if df.response_pct.isna().any():
    print('note: response_pct has no stored values (file never opened in Excel); using the recomputed values')
elif not np.allclose(calc, df.response_pct, rtol=1e-6):
    bad = df.row_id[~np.isclose(calc, df.response_pct, rtol=1e-6)].tolist()
    sys.exit(f'response_pct disagrees with the conversion rules in rows {bad}; open and save the workbook in Excel, then rerun')
df['response_pct'] = calc
H = df[(df.use_in_model == 1) & (df.sweep_of == 'humidity')]

def curves(papers_out):
    out = {}
    for (dev, ser), g in H[~H.paper.isin(papers_out)].groupby(['device_id', 'series'], sort=False):
        g = g.sort_values('RH_pct')
        name = f"{g.paper.iloc[0]} {dev} ({'light' if g.light_on.iloc[0] else 'dark'})"
        out[name] = dict(dev=dev, paper=g.paper.iloc[0], h=g.RH_pct.values / 100, s=np.log10(g.response_pct.values))
    return out

def rows_from(curve_list, interp, form):
    X, y, w = [], [], []
    for c in curve_list:
        h, s = c['h'], c['s']
        if interp:
            hh = np.linspace(h.min(), h.max(), N_INTERP.get(c['dev'], 17)); s = np.interp(hh, h, s); h = hh
        idx = list(itertools.permutations(range(len(h)), 2)) if form == 'all pairs' else [(0, j) for j in range(len(h))]
        for i, j in idx:
            X.append((h[i], h[j])); y.append(s[j] - s[i]); w.append(1.0 / len(idx))
    w = np.array(w)
    if form != 'all pairs': w = np.ones(len(w))
    return np.array(X), np.array(y), w * len(w) / w.sum()

# ------------------------------------------------------------------ models
class Model:
    stochastic = True
    def __init__(self, form): self.anti = form == 'all pairs'
    def predict(self, X):
        X = np.asarray(X, float)
        return 0.5 * (self._p(X) - self._p(X[:, ::-1])) if self.anti else self._p(X)
class NoChange(Model):
    name, stochastic = 'No change (baseline, not ML)', False
    def fit(self, X, y, w, seed): return self
    def _p(self, X): return np.zeros(len(X))
class Forest(Model):
    name = 'Random forest'
    def fit(self, X, y, w, seed):
        self.m = RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=seed, n_jobs=2).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)
class Boost(Model):
    name = 'Gradient boosting'
    def fit(self, X, y, w, seed):
        self.m = GradientBoostingRegressor(n_estimators=200, learning_rate=0.05, max_depth=2, min_samples_leaf=2,
                                           subsample=0.8, random_state=seed).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)
class MonoBoost(Model):
    name = 'Gradient boosting, monotonic'
    def fit(self, X, y, w, seed):     # the response may only fall as humidity rises
        self.m = HistGradientBoostingRegressor(max_iter=200, learning_rate=0.05, max_depth=2, min_samples_leaf=2,
                                               monotonic_cst=[1, -1], random_state=seed).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)
class GP(Model):
    name, stochastic = 'Gaussian process', False
    def fit(self, X, y, w, seed):
        k = ConstantKernel(0.01, (1e-6, 10)) * RBF([0.3, 0.3], (0.05, 10))
        self.m = GaussianProcessRegressor(k, alpha=4e-4 / w, n_restarts_optimizer=3, random_state=0).fit(X, y); return self
    def _p(self, X): return self.m.predict(X)
class SV(Model):
    name, stochastic = 'Support vector regression', False
    def fit(self, X, y, w, seed):
        self.m = SVR(kernel='rbf', C=1.0, epsilon=0.005, gamma=2.0).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)
class NN(Model):
    name = 'Neural network (8 hidden units)'
    def fit(self, X, y, w, seed):
        self.m = MLPRegressor(hidden_layer_sizes=(8,), activation='tanh', solver='lbfgs', alpha=1e-3, max_iter=5000,
                              random_state=seed).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)
MODELS = [NoChange, Forest, Boost, MonoBoost, GP, SV, NN]
pct = lambda e: 100 * (10 ** np.asarray(e) - 1)

# ------------------------------------------------------------------ test
def hide_one(curv, M, interp, form, seed, by):
    names = list(curv); per, true, pred, S_true, S_pred = {}, [], [], [], []
    group = (lambda n: n) if by == 'sensor' else (lambda n: curv[n]['paper'])
    for g in dict.fromkeys(group(n) for n in names):
        hidden = [n for n in names if group(n) == g]
        X, y, w = rows_from([curv[n] for n in names if group(n) != g], interp, form)
        m = M(form).fit(X, y, w, seed)
        for k in hidden:
            h, s = curv[k]['h'], curv[k]['s']
            p = m.predict(np.c_[np.full(len(h) - 1, h[0]), h[1:]]); t = s[1:] - s[0]
            per[k] = np.abs(p - t); true += list(t); pred += list(p)
            S_true += list(10 ** s[1:]); S_pred += list(10 ** (s[0] + p))
    r2 = lambda a, b: 1 - np.sum((np.array(a) - np.array(b)) ** 2) / np.sum((np.array(a) - np.mean(a)) ** 2)
    return per, r2(true, pred), r2(S_true, S_pred)

rows, preds, counts = [], [], []
for set_name, out in SETS.items():
    if ONLY and not set_name.startswith(ONLY): continue
    curv = curves(out)
    n_hidden = sum(len(c['h']) - 1 for c in curv.values())
    print(f'\n=== SET {set_name}: {len(curv)} curves, {len({c["dev"] for c in curv.values()})} sensors, '
          f'{len({c["paper"] for c in curv.values()})} papers, {sum(len(c["h"]) for c in curv.values())} measured points, '
          f'{n_hidden} hidden points in each test')
    for k, c in curv.items(): print(f'    {k}: ' + ', '.join(f'{100 * h:.0f}' for h in c['h']) + '% RH')
    tests = ['sensor', 'paper'] if len({c['paper'] for c in curv.values()}) < len(curv) else ['sensor']
    for interp in (False, True):
        for form in ('all pairs', 'from lowest point'):
            train = ('measured + interpolated' if interp else 'measured') + ', ' + form
            X, y, w = rows_from(list(curv.values()), interp, form)
            counts.append(dict(set=set_name, training=train, training_rows_all_curves=len(X), hidden_points_in_test=n_hidden))
            for by in tests:
                for M in MODELS:
                    t0 = time.time()
                    runs = [hide_one(curv, M, interp, form, sd, by) for sd in (SEEDS if M.stochastic else [0])]
                    overall = [pct(np.median(np.concatenate(list(r[0].values())))) for r in runs]
                    rec = dict(set=set_name, test='hide one ' + by, training=train, model=M.name, error_pct=round(float(np.median(overall)), 1),
                               error_range_over_seeds=f'{min(overall):.0f}-{max(overall):.0f}' if M.stochastic else '',
                               worst_point_pct=round(float(np.median([pct(np.max(np.concatenate(list(r[0].values())))) for r in runs])), 0),
                               R2_of_change=round(float(np.median([r[1] for r in runs])), 2),
                               R2_of_response_values=round(float(np.median([r[2] for r in runs])), 3))
                    for k in curv: rec[k] = round(float(np.median([pct(np.median(r[0][k])) for r in runs])), 0)
                    rows.append(rec)
                    print(f'    {set_name[:1]} | hide one {by:6s} | {train:45s} | {M.name:32s} error {rec["error_pct"]:5.1f}%  ({time.time() - t0:.0f} s)', flush=True)
            g = np.array(GRID) / 100                                     # final models, trained on every curve of the set
            for M in MODELS[1:]:
                P = np.array([ANCHOR['response'] * 10 ** M(form).fit(X, y, w, sd).predict(np.c_[np.full(len(g), ANCHOR['RH'] / 100), g])
                              for sd in (SEEDS if M.stochastic else [0])])
                for i, rh in enumerate(GRID):
                    preds.append(dict(set=set_name, training=train, model=M.name, RH_pct=rh, response_pct=round(float(np.median(P[:, i])), 1),
                                      low_over_seeds=round(float(P[:, i].min()), 1), high_over_seeds=round(float(P[:, i].max()), 1)))

R = pd.DataFrame(rows); Pd = pd.DataFrame(preds)
pd.set_option('display.width', 260); pd.set_option('display.max_columns', 30); pd.set_option('display.max_colwidth', 40)
for (s, b, t), g in R.groupby(['set', 'test', 'training'], sort=False):
    print(f'\n--- {s} | {b} | {t}'); print(g.drop(columns=['set', 'test', 'training']).dropna(axis=1, how='all').to_string(index=False))
R.to_csv('humidity_ml_results.csv', index=False)
pd.DataFrame(counts).to_csv('humidity_ml_training_rows.csv', index=False)
W = Pd.pivot_table(index=['set', 'training', 'model'], columns='RH_pct', values='response_pct', sort=False)
print('\n=== YOUR SENSOR: predicted response (%) at 50 ppm with light, starting from 42.59% at 20% RH'); print(W.to_string())
Pd.to_csv('humidity_ml_predictions_your_sensor.csv', index=False)
