"""Temperature-only machine-learning models for the NO2 response (set B = every temperature sweep in the workbook).

Usage:  python temperature_ml.py NO2_humidity_temperature_datasets.xlsx     (about 6 minutes on 2 cores)
Needs:  numpy, pandas, scikit-learn, openpyxl  (run with Python 3.13, scikit-learn 1.9.1, numpy 2.5.3, pandas 3.0.5)

DATA      Sheet 'temperature_B', rows with use_in_model = 1. One curve = one sensor at one NO2 concentration,
          measured at several temperatures with everything else fixed. A sensor can have several curves.
          Set B (the chosen set): every sweep.  Set A (sensitivity check only): sensors whose resistance rises in NO2
          (like yours) and whose sweep starts at room temperature (30 C or below).
          The unified response (column response_pct) is recomputed here from the input cells with the same five rules
          as the workbook formula; the script stops if the two disagree.
TASK      Predict how the response changes when the temperature changes.
          input  = starting temperature (T0) and new temperature (T1), in units of 100 C
          output = log10(response at T1 / response at T0)
TRAINING  'all pairs'          every ordered pair of points within a curve (model made antisymmetric)
          'from lowest point'  only rows that start at the curve's lowest temperature (the same form as the test)
          Every sensor carries equal weight, split equally over its curves and then over its rows. Measured points only.
TESTS     'hide one sensor'    train on the other sensors, predict every curve of the hidden sensor from its own
                               lowest-temperature point.
          'hide one paper'     hide all sensors of a paper together (the fair test: sensors from one paper share a
                               laboratory, set-up and protocol).
          Error per point = (larger / smaller - 1) x 100. Reported: median error over all hidden points, its range over
          10 seeds, worst point, per-sensor median, R2 of the predicted change (log scale).
OUTPUT    temperature_ml_results.csv, temperature_ml_predictions_your_sensor.csv, temperature_ml_training_rows.csv
"""
import sys, itertools, warnings
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, RBF
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
warnings.filterwarnings('ignore')

TABLE = sys.argv[1] if len(sys.argv) > 1 else 'NO2_humidity_temperature_datasets.xlsx'
ANCHOR = dict(response=42.59, T=27)          # your 50 ppm, light-on value at 27 C (300 K)
GRID = [27, 40, 50, 60, 70, 80, 90, 100, 110, 120, 127]
SEEDS = list(range(10))

def unified(r):
    """Same five rules as the response_pct formula in the workbook."""
    c, v = r.conversion, r.published_value
    if c == 'from Ra and Rg': return (max(r.Ra, r.Rg) / min(r.Ra, r.Rg) - 1) * 100
    if c == 'ratio': return (v - 1) * 100
    if c == 'percent (resistance falls)': return v / (100 - v) * 100
    if c == 'fraction': return v * 100
    if c == 'as published': return v
    raise ValueError(f'row {r.row_id}: unknown conversion {c!r}')

df = pd.read_excel(TABLE, sheet_name='temperature_B')
df = df[df.row_id.notna()]
calc = df.apply(unified, axis=1)
if df.response_pct.isna().any():
    print('note: response_pct has no stored values (file never opened in Excel); using the recomputed values')
elif not np.allclose(calc, df.response_pct, rtol=1e-6):
    bad = df.row_id[~np.isclose(calc, df.response_pct, rtol=1e-6)].tolist()
    sys.exit(f'response_pct disagrees with the conversion rules in rows {bad}; open and save the workbook in Excel, then rerun')
df['response_pct'] = calc
Tdf = df[(df.use_in_model == 1) & (df.sweep_of == 'temperature')]
info = Tdf.groupby('device_id').agg(paper=('paper', 'first'), rises=('resistance_change', lambda s: (s == 'rises').all()),
                                                Tmin=('T_C', 'min'), Tmax=('T_C', 'max'))
SETS = {'B: every temperature sweep': list(info.index),
        'A: check, resistance rises and starts at room temperature': [d for d, r in info.iterrows() if r.rises and r.Tmin <= 30]}

def sensors(devs):
    out = {}
    for dev in devs:
        g = Tdf[Tdf.device_id == dev]; curves = []
        for c, h in g.groupby('NO2_ppm'):
            h = h.sort_values('T_C')
            if len(h) >= 2: curves.append((h.T_C.values / 100, np.log10(h.response_pct.values), c))
        out[f"{info.loc[dev, 'paper']} | {dev}"] = curves
    return out

def rows_from(sensor_list, form):
    X, y, w = [], [], []
    for curves in sensor_list:
        n_c = len(curves)
        for T, s, _ in curves:
            idx = list(itertools.permutations(range(len(T)), 2)) if form == 'all pairs' else [(0, j) for j in range(len(T))]
            for i, j in idx:
                X.append((T[i], T[j])); y.append(s[j] - s[i]); w.append(1.0 / (n_c * len(idx)))
    w = np.array(w); return np.array(X), np.array(y), w * len(w) / w.sum()

class Model:
    stochastic = True
    def __init__(self, form): self.anti = form == 'all pairs'
    def predict(self, X):
        X = np.asarray(X, float)
        return 0.5 * (self._p(X) - self._p(X[:, ::-1])) if self.anti else self._p(X)
class NoChange(Model):
    name, stochastic = 'No change (baseline, not ML)', False
    def fit(self, X, y, w, seed): return self
    def _p(self, X): return np.zeros(len(X))
class Forest(Model):
    name = 'Random forest'
    def fit(self, X, y, w, seed):
        self.m = RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=seed, n_jobs=2).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)
class Boost(Model):
    name = 'Gradient boosting'
    def fit(self, X, y, w, seed):
        self.m = GradientBoostingRegressor(n_estimators=200, learning_rate=0.05, max_depth=2, min_samples_leaf=2,
                                           subsample=0.8, random_state=seed).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)
class GP(Model):
    name, stochastic = 'Gaussian process', False
    def fit(self, X, y, w, seed):
        k = ConstantKernel(0.01, (1e-6, 10)) * RBF([0.5, 0.5], (0.05, 10))
        self.m = GaussianProcessRegressor(k, alpha=4e-4 / w, n_restarts_optimizer=3, random_state=0).fit(X, y); return self
    def _p(self, X): return self.m.predict(X)
class SV(Model):
    name, stochastic = 'Support vector regression', False
    def fit(self, X, y, w, seed):
        self.m = SVR(kernel='rbf', C=1.0, epsilon=0.005, gamma=2.0).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)
class NN(Model):
    name = 'Neural network (8 hidden units)'
    def fit(self, X, y, w, seed):
        self.m = MLPRegressor(hidden_layer_sizes=(8,), activation='tanh', solver='lbfgs', alpha=1e-3, max_iter=5000,
                              random_state=seed).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)
MODELS = [NoChange, Forest, Boost, GP, SV, NN]
pct = lambda e: 100 * (10 ** np.asarray(e) - 1)

def hide_one(sens, M, form, seed, by='sensor'):
    names = list(sens); per, true, pred = {}, [], []
    group = (lambda n: n) if by == 'sensor' else (lambda n: n.split(' | ')[0])
    for g in dict.fromkeys(group(n) for n in names):
        hidden = [n for n in names if group(n) == g]
        X, y, w = rows_from([sens[n] for n in names if group(n) != g], form)
        m = M(form).fit(X, y, w, seed)
        for k in hidden:
            e = []
            for T, s, _ in sens[k]:
                p = m.predict(np.c_[np.full(len(T) - 1, T[0]), T[1:]]); t = s[1:] - s[0]
                e += list(np.abs(p - t)); true += list(t); pred += list(p)
            per[k] = np.array(e)
    r2 = 1 - np.sum((np.array(true) - np.array(pred)) ** 2) / np.sum((np.array(true) - np.mean(true)) ** 2)
    return per, r2

rows, preds, counts = [], [], []
for set_name, devs in SETS.items():
    sens = sensors(devs)
    n_pts = sum(len(T) for cs in sens.values() for T, _, _ in cs); n_hidden = sum(len(T) - 1 for cs in sens.values() for T, _, _ in cs)
    print(f'\n=== SET {set_name}: {len(sens)} sensors, {sum(len(cs) for cs in sens.values())} curves, '
          f'{len({n.split(" | ")[0] for n in sens})} papers, {n_pts} measured points, {n_hidden} hidden points in each test')
    for k, curves in sens.items():
        print(f'    {k}: ' + '; '.join(f'{c:g} ppm at ' + ', '.join(f'{100 * t:.0f}' for t in T) + ' C' for T, _, c in curves))
    tests = ['sensor', 'paper'] if len({n.split(' | ')[0] for n in sens}) < len(sens) else ['sensor']
    for form in ('all pairs', 'from lowest point'):
        X, y, w = rows_from(list(sens.values()), form)
        counts.append(dict(set=set_name, training='measured, ' + form, training_rows_all_sensors=len(X), hidden_points_in_test=n_hidden))
        for by in tests:
            for M in MODELS:
                runs = [hide_one(sens, M, form, sd, by) for sd in (SEEDS if M.stochastic else [0])]
                overall = [pct(np.median(np.concatenate(list(r[0].values())))) for r in runs]
                rec = dict(set=set_name, test='hide one ' + by, training='measured, ' + form, model=M.name, error_pct=round(float(np.median(overall)), 1),
                           error_range_over_seeds=f'{min(overall):.0f}-{max(overall):.0f}' if M.stochastic else '',
                           worst_point_pct=round(float(np.median([pct(np.max(np.concatenate(list(r[0].values())))) for r in runs])), 0),
                           R2_of_change=round(float(np.median([r[1] for r in runs])), 2))
                for k in sens: rec[k] = round(float(np.median([pct(np.median(r[0][k])) for r in runs])), 0)
                rows.append(rec)
                print(f'    {set_name[:1]} | hide one {by:6s} | {form:18s} | {M.name:32s} error {rec["error_pct"]:6.1f}%', flush=True)
        g = np.array(GRID) / 100                                         # final models, trained on every sensor of the set
        for M in MODELS[1:]:
            P = np.array([ANCHOR['response'] * 10 ** M(form).fit(X, y, w, sd).predict(np.c_[np.full(len(g), ANCHOR['T'] / 100), g])
                          for sd in (SEEDS if M.stochastic else [0])])
            for i, T in enumerate(GRID):
                preds.append(dict(set=set_name, training='measured, ' + form, model=M.name, T_C=T, response_pct=round(float(np.median(P[:, i])), 1),
                                  low_over_seeds=round(float(P[:, i].min()), 1), high_over_seeds=round(float(P[:, i].max()), 1)))

R = pd.DataFrame(rows); Pd = pd.DataFrame(preds)
pd.set_option('display.width', 260); pd.set_option('display.max_columns', 30); pd.set_option('display.max_colwidth', 45)
for (s, b, t), g in R.groupby(['set', 'test', 'training'], sort=False):
    print(f'\n--- {s} | {b} | {t}'); print(g.drop(columns=['set', 'test', 'training']).dropna(axis=1, how='all').to_string(index=False))
R.to_csv('temperature_ml_results.csv', index=False)
pd.DataFrame(counts).to_csv('temperature_ml_training_rows.csv', index=False)
W = Pd.pivot_table(index=['set', 'training', 'model'], columns='T_C', values='response_pct', sort=False)
print('\n=== YOUR SENSOR: predicted response (%) at 50 ppm with light, starting from 42.59% at 27 C'); print(W.to_string())
Pd.to_csv('temperature_ml_predictions_your_sensor.csv', index=False)
