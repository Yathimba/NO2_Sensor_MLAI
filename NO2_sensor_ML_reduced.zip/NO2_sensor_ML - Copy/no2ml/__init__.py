"""NO2 sensor ML: how a sensor's NO2 response changes with humidity and temperature, learned from published sensors.

    from no2ml import Settings, run_all
    out = run_all(Settings())
"""
from .config import Settings, DATASETS, GRID, FINE_GRID, ROBUST_GRID, FORMS, BASELINE
from .pipeline import run_all, run_dataset, prepare, run_holdout, versions

__version__ = '1.0.0'
