"""Compare a run's tables (results/csv/tables) with the stored reference run (tests/expected) to confirm the results reproduce.

    python tests/check_reproduction.py                 # after python run_all.py with the default settings
Rounded columns (error_pct and the like) must match exactly; unrounded values (R2, RMSE, predictions) to 1e-6. With other
versions of numpy / scikit-learn small differences can appear in the neural network and Gaussian process; the report shows
where and how large.
"""
from pathlib import Path
import numpy as np, pandas as pd
from .config import ROOT

FILES = ['summary.csv', 'holdout_results.csv', 'holdout_per_sensor.csv', 'metrics.csv', 'predictions_your_sensor.csv',
         'robustness_tests.csv', 'robustness_leave_one_out.csv', 'parity_humidity.csv', 'parity_temperature.csv',
         'curve_humidity.csv', 'curve_temperature.csv', 'dataset_humidity.csv', 'dataset_temperature.csv', 'dataset_temperature_local.csv']


def compare(new_dir=ROOT / 'results' / 'csv' / 'tables', ref_dir=ROOT / 'tests' / 'expected', rtol=1e-6, atol=1e-6):
    rows = []
    for f in FILES:
        a, b = Path(new_dir) / f, Path(ref_dir) / f
        if not b.exists(): rows.append(dict(table=f, status='no reference', detail='')); continue
        if not a.exists(): rows.append(dict(table=f, status='MISSING', detail='not produced by this run')); continue
        A, B = pd.read_csv(a), pd.read_csv(b)
        if list(A.columns) != list(B.columns) or len(A) != len(B):
            rows.append(dict(table=f, status='DIFFERENT', detail=f'shape {A.shape} vs reference {B.shape}')); continue
        worst, bad = 0.0, []
        for c in A.columns:
            x, y = A[c], B[c]
            if pd.api.types.is_numeric_dtype(x) and pd.api.types.is_numeric_dtype(y):
                xv, yv = x.to_numpy(float), y.to_numpy(float)
                same_nan = np.isnan(xv) == np.isnan(yv)
                ok = same_nan & (np.isnan(xv) | np.isclose(xv, yv, rtol=rtol, atol=atol))
                d = np.nanmax(np.abs(xv - yv)) if np.any(~np.isnan(xv)) else 0.0
                worst = max(worst, float(d) if np.isfinite(d) else 0.0)
                if not ok.all(): bad.append(f'{c} ({int((~ok).sum())} cells, max diff {d:.3g})')
            else:
                ok = (x.fillna('') .astype(str) == y.fillna('').astype(str))
                if not ok.all(): bad.append(f'{c} ({int((~ok).sum())} cells)')
        rows.append(dict(table=f, status='same' if not bad else 'DIFFERENT', detail='; '.join(bad) if bad else f'largest difference {worst:.2g}'))
    R = pd.DataFrame(rows)
    return R, bool((R.status.isin(['same', 'no reference'])).all())
