"""Every setting of the analysis in one place. Change a value here, or pass your own Settings(...) to the pipeline."""
from dataclasses import dataclass, field, asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# The datasets the pipeline can run. Each has a factor (humidity or temperature) and a variant of the readings.
#   humidity           every humidity sweep (minus the papers excluded in Settings.exclude_papers)
#   temperature        every temperature sweep, values as delivered
#   temperature_local  the same, but 14 Kumar 2018 (Nanotechnology) pulses measured from their local baseline
DATASETS = {
    'humidity': dict(factor='humidity', variant=None, label='humidity'),
    'temperature': dict(factor='temperature', variant=None, label='temperature (as delivered)'),
    'temperature_local': dict(factor='temperature', variant='local_baseline', label='temperature (local baselines)'),
}

# Prediction grids for your sensor (in % RH or C). The fine grids are used for the figures and curve sheets.
GRID = {'humidity': [20, 30, 40, 50, 60, 70, 80, 90], 'temperature': [27, 40, 50, 60, 70, 80, 90, 100, 110, 120, 127]}
FINE_GRID = {'humidity': list(range(20, 91)), 'temperature': list(range(27, 128))}
# Points at which the leave-one-paper-out robustness check reports your sensor's predicted response
ROBUST_GRID = {'humidity': [20, 40, 60, 80, 90], 'temperature': [27, 60, 100, 127]}

FORMS = ('all pairs', 'from lowest point')
BASELINE = 'No change (baseline, not ML)'


@dataclass
class Settings:
    data_file: Path = ROOT / 'data' / 'NO2_sensor_data.xlsx'
    out_dir: Path = ROOT / 'results'
    # rows per dataset after interpolation inside each curve (0 = measured points only)
    n_total: int = 100
    # also run every test on the measured points only, for the "measured only" comparison columns
    compare_measured_only: bool = True
    seeds: tuple = tuple(range(10))
    # hold-out tests: 'paper' (the fair test), 'lab' (stricter), 'sensor' (one sensor, or for humidity one curve)
    tests: tuple = ('paper', 'lab', 'sensor')
    datasets: tuple = ('humidity', 'temperature', 'temperature_local')
    # papers left out of each factor in this analysis (names as in the 'paper' column)
    exclude_papers: dict = field(default_factory=lambda: {'humidity': ['Chen 2021'], 'temperature': []})
    # model reported in the paper outputs, per factor: None = the configuration with the lowest median error in the
    # hide-one-paper test; or a (training form, model name) pair, e.g. ('all pairs', 'Support vector regression')
    paper_model: dict = field(default_factory=lambda: {'humidity': None, 'temperature': None})
    # configurations left out of the shaded band in the figures (numerically unstable fits); they stay in every table
    band_exclude: dict = field(default_factory=lambda: {'humidity': [('all pairs', 'Gaussian process')], 'temperature': []})
    # your sensor's reading that anchors every prediction (your_sensor sheet): 42.59% at 50 ppm, 520 nm, 20% RH, 27 C
    anchor_row_id: int = 165
    # extra configurations checked in the leave-one-paper-out robustness test (the paper model is always included)
    robustness_models: tuple = (('all pairs', 'Gradient boosting'), ('all pairs', 'Random forest'))
    # write Excel workbooks, CSV copies and figures
    write_outputs: bool = True
    verbose: bool = True

    def as_dict(self):
        d = asdict(self)
        return {k: (str(v) if isinstance(v, Path) else v) for k, v in d.items()}
