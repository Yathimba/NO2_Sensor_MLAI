"""Reading the input workbook, unifying responses, building curves, and padding curves by interpolation.

A curve is one sensor measured at several humidities (or temperatures) with everything else fixed:
    humidity     device_id + series (one figure panel)
    temperature  device_id + NO2_ppm
The models never compare values across curves; they learn how a response changes along a curve.
"""
import numpy as np, pandas as pd


def unified_response(r):
    """Response in % as (higher resistance / lower resistance - 1) x 100, from the reading and its conversion rule."""
    c, v = r.conversion, r.published_value
    if c == 'from Ra and Rg': return (max(r.Ra, r.Rg) / min(r.Ra, r.Rg) - 1) * 100
    if c == 'ratio': return (v - 1) * 100
    if c == 'percent (resistance falls)': return v / (100 - v) * 100
    if c == 'fraction': return v * 100
    if c == 'as published': return v
    raise ValueError(f'row {r.row_id}: unknown conversion {c!r}')


def _sheet(path, name):
    d = pd.read_excel(path, sheet_name=name)
    d = d[d.row_id.notna()].copy()
    calc = d.apply(unified_response, axis=1)
    if 'response_pct' in d and d.response_pct.notna().all():
        bad = ~np.isclose(calc, d.response_pct, rtol=1e-9, atol=0)
        if bad.any():
            raise ValueError(f'{name}: response_pct disagrees with the conversion rule in rows {d.row_id[bad].tolist()}; '
                             'fix the reading or clear response_pct')
    d['response_pct'] = calc
    return d


def load_data(path):
    """All sheets the pipeline needs, with response_pct recomputed from the readings."""
    data = {s: _sheet(path, s) for s in ('humidity', 'temperature', 'your_sensor')}
    data['sources'] = pd.read_excel(path, sheet_name='sources')
    return data


def readings(data, factor, variant=None):
    """The rows of one factor, optionally with the local-baseline variant applied (temperature only)."""
    d = data[factor].copy()
    if variant == 'local_baseline':
        m = d.published_value_local_baseline.notna()
        d.loc[m, 'published_value'] = d.loc[m, 'published_value_local_baseline']
        d['response_pct'] = d.apply(unified_response, axis=1)
    elif variant is not None:
        raise ValueError(f'unknown variant {variant!r}')
    return d


def anchor(data, row_id):
    """Your sensor's reading that every prediction starts from: response (%), RH (%), T (C)."""
    r = data['your_sensor'].set_index('row_id').loc[row_id]
    return dict(response=float(r.response_pct), RH=float(r.RH_pct), T=float(r.T_C), NO2_ppm=float(r.NO2_ppm),
                light=r.light_source, source=r.source)


def build_curves(df, factor, exclude_papers=()):
    """Curves of one factor, in a fixed order (the order matters for the tie-breaks in padding and the row order in training).
    x is RH or T divided by 100; s is log10(response %)."""
    D = df[(df.use_in_model == 1) & (df.sweep_of == factor)]
    if len(exclude_papers):
        D = D[~D.paper.isin(list(exclude_papers))]
    curves = []
    if factor == 'humidity':
        for (dev, ser), g in D.groupby(['device_id', 'series'], sort=False):
            g = g.sort_values('RH_pct')
            name = f"{g.paper.iloc[0]} {dev} ({'light' if g.light_on.iloc[0] else 'dark'})"
            curves.append(dict(name=name, unit=name, dev=dev, paper=g.paper.iloc[0], lab=g.lab.iloc[0], label=ser,
                               NO2_ppm=float(g.NO2_ppm.iloc[0]), light_on=int(g.light_on.iloc[0]),
                               row_id=g.row_id.astype(int).values, x=g.RH_pct.values / 100, s=np.log10(g.response_pct.values)))
    else:
        info = D.groupby('device_id').agg(paper=('paper', 'first'), lab=('lab', 'first'))
        for dev in info.index:
            g = D[D.device_id == dev]
            for c, h in g.groupby('NO2_ppm'):
                h = h.sort_values('T_C')
                if len(h) >= 2:
                    curves.append(dict(name=f"{info.loc[dev, 'paper']} | {dev} | {c:g} ppm", unit=f"{info.loc[dev, 'paper']} | {dev}",
                                       dev=dev, paper=info.loc[dev, 'paper'], lab=info.loc[dev, 'lab'], label=f'{c:g} ppm',
                                       NO2_ppm=float(c), light_on=int(h.light_on.iloc[0]),
                                       row_id=h.row_id.astype(int).values, x=h.T_C.values / 100, s=np.log10(h.response_pct.values)))
    return curves


def pad_curves(curves, n_total):
    """Copies of the curves with points added inside each curve's measured range until there are n_total rows in all.

    Each new point goes into the widest remaining gap of any curve (gap width / (points already in it + 1)), so every curve
    ends up with roughly even spacing; ties go to the curve with the fewest new points so far, then to the earlier gap.
    Its response is read off the straight line, in log10(response), between the two measured neighbours.
    n_total = 0 adds nothing. Adds keys x_all, s_all, syn (1 = interpolated) and row_id_all to each curve."""
    out = [dict(c) for c in curves]
    n_meas = sum(len(c['x']) for c in out)
    n_new = max(0, n_total - n_meas) if n_total else 0
    gaps = [(ci, gi, c['x'][gi + 1] - c['x'][gi]) for ci, c in enumerate(out) for gi in range(len(c['x']) - 1)]
    k = [0] * len(gaps)
    added = [0] * len(out)
    for _ in range(n_new):
        j = max(range(len(gaps)), key=lambda j: (round(gaps[j][2] / (k[j] + 1), 9), -added[gaps[j][0]], -j))
        k[j] += 1; added[gaps[j][0]] += 1
    for ci, c in enumerate(out):
        xs, ss, syn, ids = list(c['x']), list(c['s']), [0] * len(c['x']), list(c['row_id'])
        for (gci, gi, wdt), kk in zip(gaps, k):
            if gci != ci or kk == 0: continue
            x0, x1, s0, s1 = c['x'][gi], c['x'][gi + 1], c['s'][gi], c['s'][gi + 1]
            for i in range(1, kk + 1):
                xn = x0 + (x1 - x0) * i / (kk + 1)
                xs.append(xn); ss.append(s0 + (s1 - s0) * (xn - x0) / (x1 - x0)); syn.append(1); ids.append(-1)
        o = np.argsort(xs, kind='stable')
        c['x_all'], c['s_all'], c['syn'], c['row_id_all'] = np.array(xs)[o], np.array(ss)[o], np.array(syn)[o], np.array(ids)[o]
    return out


def dataset_table(curves, factor):
    """The padded dataset as a table: one row per point, measured or interpolated."""
    xname = 'RH_pct' if factor == 'humidity' else 'T_C'
    rows = []
    for c in curves:
        for x, s, f, rid in zip(c['x_all'], c['s_all'], c['syn'], c['row_id_all']):
            rows.append({'row_id': (int(rid) if rid >= 0 else pd.NA), 'paper': c['paper'], 'lab': c['lab'], 'device_id': c['dev'],
                         'curve': c['label'], 'NO2_ppm': c['NO2_ppm'], 'light_on': c['light_on'], xname: round(100 * float(x), 6),
                         'response_pct': float(10 ** s), 'synthetic': int(f)})
    d = pd.DataFrame(rows)
    d['row_id'] = d.row_id.astype('Int64')
    return d


def curve_table(curves, factor):
    """One row per curve: what it is and where it was measured."""
    xname = 'RH (%)' if factor == 'humidity' else 'T (C)'
    return pd.DataFrame([dict(curve=c['name'], paper=c['paper'], lab=c['lab'], device_id=c['dev'], points=len(c['x']),
                              **{f'{xname} measured': ', '.join(f'{100 * v:g}' for v in c['x'])},
                              **{'response (%) measured': ', '.join(f'{10 ** v:.3g}' for v in c['s'])}) for c in curves])
