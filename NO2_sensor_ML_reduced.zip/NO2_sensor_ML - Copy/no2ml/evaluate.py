"""Hold-out tests, their summaries (as in the original scripts), and R2 / RMSE on the held-out points.

TESTS   'hide one paper'   train on every other paper, predict the hidden paper's curves (the fair test: curves from one
                           paper share a laboratory, set-up and protocol)
        'hide one lab'     hide all papers of one institution together (stricter)
        'hide one sensor'  hide one sensor (temperature) or one curve (humidity) at a time (least strict)
        Each hidden curve is predicted from its own lowest MEASURED point; only measured points are scored, never the
        interpolated ones, so errors are comparable with and without interpolation.
ERROR   per point = (larger / smaller - 1) x 100 = 100 x (10^|predicted change - true change| - 1).
"""
import numpy as np, pandas as pd
from .models import training_rows
from .config import BASELINE, FORMS

pct = lambda e: 100 * (10 ** np.asarray(e) - 1)
GROUPERS = {'sensor': lambda c: c['unit'], 'paper': lambda c: c['paper'], 'lab': lambda c: c['lab']}
TEST_LABEL = {'sensor': 'hide one sensor', 'paper': 'hide one paper', 'lab': 'hide one lab'}


def holdout_predictions(curves, factor, form, test, models, seeds, log=None):
    """One row per hidden measured point, model and seed: the true and predicted change in log10(response)."""
    group = GROUPERS[test]
    groups = list(dict.fromkeys(group(c) for c in curves))
    train = {g: training_rows([c for c in curves if group(c) != g], form, factor) for g in groups}
    recs = []
    for M in models:
        for sd in (seeds if M.stochastic else [0]):
            for g in groups:
                X, y, w = train[g]
                m = M(form, factor).fit(X, y, w, sd)
                for c in curves:
                    if group(c) != g: continue
                    x, s = c['x'], c['s']
                    p = m.predict(np.c_[np.full(len(x) - 1, x[0]), x[1:]]); t = s[1:] - s[0]
                    for k in range(len(t)):
                        recs.append((M.name, sd, g, c['name'], c['unit'], c['paper'], c['lab'], k + 1, float(x[0]) * 100,
                                     float(x[k + 1]) * 100, float(s[0]), float(s[k + 1]), float(t[k]), float(p[k])))
        if log: log(f'      {TEST_LABEL[test]:15s} | {form:17s} | {M.name}')
    d = pd.DataFrame(recs, columns=['model', 'seed', 'hidden_group', 'curve', 'sensor', 'paper', 'lab', 'point', 'x_start', 'x',
                                    's_start', 's', 'true_change', 'pred_change'])
    d.insert(0, 'training_form', form); d.insert(0, 'test', TEST_LABEL[test])
    return d


def run_tests(curves, factor, models, seeds, tests, log=None):
    """Every test, training form and model; rows in the original scripts' order (form, then test, then model)."""
    return pd.concat([holdout_predictions(curves, factor, form, t, models, seeds, log) for form in FORMS for t in tests],
                     ignore_index=True)


def summarize(pred, curves, models, set_label, train_label):
    """Results table in the original scripts' layout: median error over all hidden points (median over seeds), its range over
    seeds, worst point, R2 of the predicted change, and the median error per sensor (one column each)."""
    units = list(dict.fromkeys(c['unit'] for c in curves))
    stoch = {M.name: M.stochastic for M in models}
    rows = []
    for (test, form, model), d in pred.groupby(['test', 'training_form', 'model'], sort=False):
        overall, worst, r2s, per = [], [], [], {u: [] for u in units}
        for sd, e in d.groupby('seed', sort=False):
            t, p = e.true_change.to_numpy(), e.pred_change.to_numpy()
            err = np.abs(p - t)
            overall.append(pct(np.median(err))); worst.append(pct(np.max(err)))
            r2s.append(1 - np.sum((t - p) ** 2) / np.sum((t - np.mean(t)) ** 2))
            su = e.sensor.to_numpy()
            for u in units: per[u].append(pct(np.median(err[su == u])))
        rec = dict(set=set_label, test=test, training=f'{train_label}, {form}', model=model, error_pct=round(float(np.median(overall)), 1),
                   error_range_over_seeds=f'{min(overall):.0f}-{max(overall):.0f}' if stoch[model] else '',
                   worst_point_pct=round(float(np.median(worst)), 0), R2_of_change=round(float(np.median(r2s)), 2))
        for u in units: rec[u] = round(float(np.median(per[u])), 0)
        rows.append(rec)
    return pd.DataFrame(rows)


def heldout_points(pred, test='hide one paper'):
    """Per hidden point and configuration, the median predicted change over seeds (for parity plots, R2 and RMSE)."""
    d = pred[pred.test == test]
    keys = ['training_form', 'model', 'curve', 'point']
    first = d.drop_duplicates(keys)[keys + ['sensor', 'paper', 'lab', 'x_start', 'x', 's_start', 's']]
    med = d.groupby(keys, sort=False).pred_change.median().reset_index()
    out = first.merge(med, on=keys, how='left')
    return out[['training_form', 'model', 'curve', 'sensor', 'paper', 'lab', 'x_start', 'x', 's_start', 's', 'pred_change']].reset_index(drop=True)


def metrics(points):
    """R2 and RMSE per configuration, on response values (%) and on the change log10(response / starting response),
    plus the median miss (%). Computed from the median prediction over seeds at each held-out measured point."""
    P = points.copy()
    P['true_change'] = P.s - P.s_start
    P['S_meas'] = 10 ** P.s; P['S_start'] = 10 ** P.s_start; P['S_pred'] = 10 ** (P.s_start + P.pred_change)
    out = []
    for (form, model), d in P.groupby(['training_form', 'model'], sort=False):
        t, p = d.true_change.values, d.pred_change.values
        r2c = 1 - np.sum((t - p) ** 2) / np.sum((t - t.mean()) ** 2); rmsec = np.sqrt(np.mean((t - p) ** 2))
        S, Sh = d.S_meas.values, d.S_pred.values
        r2s = 1 - np.sum((S - Sh) ** 2) / np.sum((S - S.mean()) ** 2); rmses = np.sqrt(np.mean((S - Sh) ** 2))
        miss = 100 * (10 ** np.median(np.abs(t - p)) - 1)
        out.append(dict(training_form=form, model=model, n=len(d), R2_change=r2c, RMSE_change_log10=rmsec, RMSE_change_factor=10 ** rmsec,
                        R2_response=r2s, RMSE_response_pct=rmses, median_miss_pct=miss))
    return P, pd.DataFrame(out)


def select_paper_model(results):
    """The configuration with the lowest median error in the hide-one-paper test (ties: the first in table order)."""
    R = results[(results.test == 'hide one paper') & (results.model != BASELINE)]
    if not len(R): raise ValueError('the hide-one-paper test is needed to choose the paper model')
    b = R.loc[R.error_pct.idxmin()]
    return (b.training.split(', ')[-1], b.model)
