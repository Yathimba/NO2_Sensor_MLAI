"""Excel workbooks for people and code: every sheet is one table with its header in row 1 (no merged cells, no notes
under tables). Charts float beside their tables and are ignored by pandas.read_excel."""
import numpy as np, pandas as pd, openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.chart import BarChart, ScatterChart, Reference, Series
from openpyxl.chart.marker import Marker
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.utils import get_column_letter as L
from .config import BASELINE, FORMS
from . import tables as T

A = 'Arial'
HDR = PatternFill('solid', fgColor='FF2F4B5C'); BLUE_FILL = PatternFill('solid', fgColor='FFDCE9F8'); GREY_FILL = PatternFill('solid', fgColor='FFEDEDED')
thin = Side(style='thin', color='FFBFBFBF'); BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
BLUE, LIGHT, GRAY, INK = '2A78D6', 'A9C8EE', '8C8B86', '0B0B0B'

FMT = {'error_pct': '0.0', 'no_change_error_pct': '0.0', 'best_error_pct': '0.0', 'measured_only_best_error_pct': '0.0',
       'error_pct_hide_one_paper': '0.0', 'error_pct_hide_one_lab': '0.0', 'worst_point_pct': '0', 'R2_of_change': '0.00',
       'R2_of_change_hide_one_paper': '0.00', 'R2_of_change_hide_one_lab': '0.00', 'R2_response': '0.00', 'R2_change': '0.00',
       'RMSE_response_pct': '0.0', 'RMSE_change_log10': '0.000', 'RMSE_change_factor': '0.00', 'median_miss_pct': '0.0',
       'low_over_seeds': '0.0', 'high_over_seeds': '0.0', 'starting_response_pct': '0.00', 'measured_response_pct': '0.00',
       'predicted_response_pct': '0.00', 'no_change_prediction_pct': '0.00', 'measured_ratio_to_start': '0.000',
       'predicted_ratio_to_start': '0.000', 'all pairs': '0.00', 'from lowest point': '0.00'}
WRAP = {'description', 'settings', 'meaning', 'best_model', 'measured_only_best_model'}


def write_table(wb, name, df, fmt=None, fill=None, widths=None, default_fmt=None, freeze='A2', wrap=WRAP):
    """One table at A1. fmt: column -> number format; fill(row) -> PatternFill or None; widths: column -> width."""
    ws = wb.create_sheet(name)
    cols = list(df.columns); fmt = {**FMT, **(fmt or {})}
    for j, c in enumerate(cols, 1):
        cell = ws.cell(1, j, str(c)); cell.font = Font(name=A, size=10, bold=True, color='FFFFFFFF'); cell.fill = HDR
        cell.alignment = Alignment(wrap_text=True, vertical='center'); cell.border = BOX
    for i, rec in enumerate(df.itertuples(index=False), 2):
        f = fill(rec) if fill else None
        for j, v in enumerate(rec, 1):
            if isinstance(v, (np.floating, np.integer)): v = v.item()
            if v is pd.NA or v is None or (isinstance(v, float) and np.isnan(v)): v = None
            cell = ws.cell(i, j, v); cell.font = Font(name=A, size=10, bold=bool(f is BLUE_FILL)); cell.border = BOX
            cell.alignment = Alignment(vertical='top', wrap_text=cols[j - 1] in wrap)
            if isinstance(v, float):
                nf = fmt.get(cols[j - 1], default_fmt)
                if nf: cell.number_format = nf
            if f: cell.fill = f
    for j, c in enumerate(cols, 1):
        w = (widths or {}).get(c)
        if w is None:
            sample = [len(f'{v:.2f}') if isinstance(v, float) else len(str(v)) for v in df[c].head(80)]
            w = min(max([10, len(str(c)) * 0.9 + 2] + [s + 2 for s in sample]), 60 if c in wrap else 36)
        ws.column_dimensions[L(j)].width = w
    ws.row_dimensions[1].height = 30
    if freeze: ws.freeze_panes = freeze
    ws.auto_filter.ref = f'A1:{L(len(cols))}{len(df) + 1}'
    return ws


def readme(wb, rows):
    df = pd.DataFrame(rows, columns=['topic', 'description'])
    return write_table(wb, 'README', df, widths={'topic': 26, 'description': 130}, wrap={'description', 'topic'})


def _row_fill(paper=None):
    def f(rec):
        d = rec._asdict()
        if d.get('paper_model') == 'yes': return BLUE_FILL
        if d.get('model') == BASELINE or d.get('baseline') == 'yes': return GREY_FILL
        return None
    return f


def _style_chart(ch, title, xt, yt, w=18, h=9):
    ch.title = title; ch.x_axis.title = xt; ch.y_axis.title = yt; ch.width = w; ch.height = h
    ch.x_axis.delete = False; ch.y_axis.delete = False; ch.legend.position = 'b'


# ------------------------------------------------------------------------------------------------ workbook 1
def tests_workbook(out, path, readme_rows):
    wb = openpyxl.Workbook(); wb.remove(wb.active)
    readme(wb, readme_rows)
    write_table(wb, 'summary', T.summary(out), widths={'best_model': 30, 'measured_only_best_model': 40})
    for name, D in T.datasets(out).items():
        write_table(wb, f'dataset_{name}', D, fmt={'response_pct': '0.000', 'RH_pct': '0.0', 'T_C': '0.0'},
                    fill=lambda r: GREY_FILL if r.synthetic == 1 else None)
    write_table(wb, 'curves', T.curves(out))
    from .models import model_table
    mt = pd.concat([model_table(f).assign(factor=f) for f in ('humidity', 'temperature')], ignore_index=True)[['factor', 'model', 'random', 'settings']]
    write_table(wb, 'models', mt, widths={'settings': 110})
    write_table(wb, 'holdout_results', T.holdout_results(out), fill=_row_fill())
    write_table(wb, 'holdout_per_sensor', T.holdout_per_sensor(out), fmt={'error_pct': '0'})
    write_table(wb, 'predictions_your_sensor', T.predictions(out), fmt={'response_pct': '0.0', 'x': '0'})
    wb.save(path)


# ------------------------------------------------------------------------------------------------ workbook 2
def paper_workbook(out, path, readme_rows, names, band_exclude):
    wb = openpyxl.Workbook(); wb.remove(wb.active)
    readme(wb, readme_rows)
    M = T.metrics(out, names)
    write_table(wb, 'metrics', M, fill=_row_fill(), widths={'model': 32})

    # chart data: one block per (dataset, metric), rows = algorithms, columns = the two training forms
    rows = []
    for name in names:
        Mi = M[M.dataset == name]
        for metric in ('R2_response', 'RMSE_response_pct', 'R2_change'):
            for a in dict.fromkeys(Mi.model):
                v = {f: float(Mi[(Mi.model == a) & (Mi.training_form == f)][metric].iloc[0]) for f in FORMS}
                rows.append(dict(dataset=name, metric=metric, model=a.replace(' (baseline, not ML)', ' (baseline)'), **v))
    CD = pd.DataFrame(rows)
    wsd = write_table(wb, 'chart_data', CD, widths={'model': 32})
    wsc = wb.create_sheet('charts')
    wsc.cell(1, 1, 'Bar charts of the metrics sheet (data: chart_data). Bars beyond the axis limits are clipped; read their values from metrics.').font = Font(name=A, size=10, italic=True)
    labels = {'R2_response': 'R2, response values', 'RMSE_response_pct': 'RMSE, response (% points)', 'R2_change': 'R2, change (honest skill)'}
    k = 0
    for (name, metric), blk in CD.groupby(['dataset', 'metric'], sort=False):
        r0, r1 = blk.index.min() + 2, blk.index.max() + 2
        ch = BarChart(); ch.type = 'col'; ch.grouping = 'clustered'
        for col, title, color in ((4, 'all pairs', BLUE), (5, 'from lowest point', LIGHT)):
            s = Series(Reference(wsd, min_col=col, min_row=r0, max_row=r1), title=title)
            s.graphicalProperties.solidFill = color; ch.series.append(s)
        ch.set_categories(Reference(wsd, min_col=3, min_row=r0, max_row=r1))
        _style_chart(ch, f'{name.capitalize()} model: {labels[metric]}', 'Algorithm', labels[metric])
        ch.x_axis.tickLblPos = 'low'
        vals = blk[['all pairs', 'from lowest point']].to_numpy().ravel()
        if metric.startswith('R2') and vals.min() < -2: ch.y_axis.scaling.min = -2; ch.y_axis.scaling.max = 1
        if metric.startswith('RMSE') and vals.max() > 5 * np.median(vals):
            ch.y_axis.scaling.min = 0; ch.y_axis.scaling.max = float(np.ceil(np.sort(vals)[-3] * 1.3 / 5) * 5)
        wsc.add_chart(ch, f'{"A" if k % 2 == 0 else "L"}{3 + (k // 2) * 19}')
        k += 1

    helpers, pending = [], {}
    for name in names:
        d = out['datasets'][name]
        P = T.parity(out, name)
        ws = write_table(wb, f'parity_{name}', P, fmt={P.columns[2]: 'General', P.columns[3]: 'General'}, widths={'curve': 44, 'paper': 26})
        n = len(P)
        lo = float(min(P.measured_response_pct.min(), P.predicted_response_pct.min(), P.starting_response_pct.min()))
        hi = float(max(P.measured_response_pct.max(), P.predicted_response_pct.max(), P.starting_response_pct.max()))
        amin, amax = 10 ** np.floor(np.log10(lo)), 10 ** np.ceil(np.log10(hi))
        helpers += [dict(chart=f'parity_{name}', series='y = x', x=amin, y=amin), dict(chart=f'parity_{name}', series='y = x', x=amax, y=amax)]
        ch = ScatterChart(); ch.style = 13
        for ycol, title, color in ((7, f'{d["paper_model"][1]} (held-out papers)', BLUE), (8, 'No change (baseline)', GRAY)):
            s = Series(Reference(ws, min_col=ycol, min_row=2, max_row=n + 1), Reference(ws, min_col=6, min_row=2, max_row=n + 1), title=title)
            s.marker = Marker(symbol='circle', size=7); s.marker.graphicalProperties = GraphicalProperties(solidFill=color)
            s.marker.graphicalProperties.line.solidFill = color; s.graphicalProperties.line.noFill = True; ch.series.append(s)
        _style_chart(ch, f'{name.capitalize()} model: predicted vs measured response, held-out papers (log axes)',
                     'Measured response (%)', 'Predicted response (%)', w=18, h=12)
        ch.x_axis.scaling.logBase = 10; ch.y_axis.scaling.logBase = 10
        ch.x_axis.scaling.min = float(amin); ch.x_axis.scaling.max = float(amax); ch.y_axis.scaling.min = float(amin); ch.y_axis.scaling.max = float(amax)
        ws.add_chart(ch, 'L2'); pending[name] = ch

    for name in names:
        d = out['datasets'][name]
        C, nband = T.curve_wide(out, name, band_exclude.get(d['factor'], []))
        ws = write_table(wb, f'curve_{name}', C, default_fmt='0.0', widths={c: 14 for c in C.columns})
        n = len(C); hum = d['factor'] == 'humidity'; xc = 1 if hum else 2; off = 0 if hum else 1
        ch = ScatterChart(); ch.style = 13
        for col, title, color, dash, width in ((2 + off, f'{d["paper_model"][1]} (paper model)', BLUE, None, 28575),
                                               (3 + off, 'band low', LIGHT, 'dash', 12700), (4 + off, 'band high', LIGHT, 'dash', 12700),
                                               (5 + off, 'no change', GRAY, 'sysDash', 12700)):
            s = Series(Reference(ws, min_col=col, min_row=2, max_row=n + 1), Reference(ws, min_col=xc, min_row=2, max_row=n + 1), title=title)
            s.marker = Marker(symbol='none'); s.graphicalProperties.line.solidFill = color; s.graphicalProperties.line.width = width
            if dash: s.graphicalProperties.line.dashStyle = dash
            s.smooth = False; ch.series.append(s)
        s = Series(Reference(ws, min_col=6 + off, min_row=2, max_row=n + 1), Reference(ws, min_col=xc, min_row=2, max_row=n + 1), title='measured (your sensor)')
        s.marker = Marker(symbol='circle', size=8); s.marker.graphicalProperties = GraphicalProperties(solidFill=INK); s.graphicalProperties.line.noFill = True
        ch.series.append(s)
        a = d['anchor']
        _style_chart(ch, f'Predicted response of your sensor vs {"relative humidity" if hum else "temperature"} '
                         f'({a["NO2_ppm"]:g} ppm NO2, {a["light"]})', 'Relative humidity (%)' if hum else 'Temperature (K)', 'Response (%)', w=18, h=11)
        xs = C.iloc[:, xc - 1]
        ch.x_axis.scaling.min = float(xs.min()); ch.x_axis.scaling.max = float(xs.max())
        ch.y_axis.scaling.min = 0; ch.y_axis.scaling.max = float(np.ceil(max(C.band_high.max(), C.paper_model.max(), a['response']) * 1.15 / 10) * 10)
        ws.add_chart(ch, f'{L(len(C.columns) + 2)}2')

    RT, LO = T.robustness_tests(out, names), T.leave_one_paper_out(out, names)
    if len(RT): write_table(wb, 'robustness_tests', RT, fill=_row_fill(), widths={'model': 32})          # needs the paper and lab tests
    if len(LO): write_table(wb, 'robustness_leave_one_out', LO, fmt={'response_pct': '0.0'}, widths={'paper_left_out': 30, 'model': 30})

    H = pd.DataFrame(helpers)
    wsh = write_table(wb, 'chart_helpers', H, default_fmt='0.###')
    for name in names:                                  # now that chart_helpers exists, add each parity chart's y = x line
        ch = pending[name]
        idx = [i for i, h in enumerate(helpers) if h['chart'] == f'parity_{name}']
        r0, r1 = idx[0] + 2, idx[-1] + 2
        s = Series(Reference(wsh, min_col=4, min_row=r0, max_row=r1), Reference(wsh, min_col=3, min_row=r0, max_row=r1), title='y = x')
        s.marker = Marker(symbol='none'); s.graphicalProperties.line.solidFill = INK; s.graphicalProperties.line.dashStyle = 'dash'
        ch.series.append(s)
    wb.save(path)
