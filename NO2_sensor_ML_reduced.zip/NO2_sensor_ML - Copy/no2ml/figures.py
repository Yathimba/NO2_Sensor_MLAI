"""Figures for the paper: predicted response of your sensor vs humidity / temperature, and parity plots of the held-out papers."""
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.ticker
import matplotlib.pyplot as plt
from . import tables as T

INK, INK2, GRIDC, BLUE, GREY = '#0b0b0b', '#52514e', '#e4e3df', '#2a78d6', '#8c8b86'
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'Liberation Sans', 'DejaVu Sans'], 'font.size': 9,
                     'axes.linewidth': 0.8, 'pdf.fonttype': 42, 'svg.fonttype': 'none'})
LAYOUT = {'humidity': dict(xlabel='Relative humidity (%)', xlim=(20, 90), xticks=np.arange(20, 91, 10), ytop=60),
          'temperature': dict(xlabel='Temperature (K)', xlim=(300, 400), xticks=np.arange(300, 401, 20), ytop=80)}


def _axes(ax):
    ax.tick_params(colors=INK2, width=0.8, length=3)
    for s in ('top', 'right'): ax.spines[s].set_visible(False)
    for s in ('left', 'bottom'): ax.spines[s].set_color(INK2)


def _save(fig, stem):
    fig.savefig(f'{stem}.png', dpi=300, bbox_inches='tight', pad_inches=0.06)
    fig.savefig(f'{stem}.pdf', bbox_inches='tight', pad_inches=0.06)
    plt.close(fig)


def response_curve(out, name, band_exclude, stem):
    d = out['datasets'][name]; fac = d['factor']; lay = LAYOUT[fac]; a = d['anchor']
    C, nband = T.curve_wide(out, name, band_exclude)
    x = (C.RH_pct if fac == 'humidity' else C.T_K).to_numpy(float)
    x_meas = a['RH'] if fac == 'humidity' else a['T'] + 273
    form, model = d['paper_model']
    label = f'{model} (lowest fair-test error)' if d.get('paper_model_rule', '').startswith('lowest') else f'{model}, {form} training'
    fig, ax = plt.subplots(figsize=(4.0, 3.5), dpi=300)
    ax.fill_between(x, C.band_low, C.band_high, color=BLUE, alpha=0.13, linewidth=0, label=f'Range of {nband} model configurations')
    ax.axhline(a['response'], color=INK2, linewidth=0.9, linestyle=(0, (4, 3)), label='No change from measured value')
    ax.plot(x, C.paper_model, color=BLUE, linewidth=1.6, solid_capstyle='round', label=label)
    ax.plot([x_meas], [a['response']], 'o', markersize=6, color=INK, markeredgecolor='white', markeredgewidth=1.2, zorder=5, clip_on=False,
            label=f'Measured ({a["source"]})')
    top = max(lay['ytop'], float(np.ceil(max(C.band_high.max(), a['response']) * 1.05 / 10) * 10))
    ax.set_xlim(*lay['xlim']); ax.set_ylim(0, top); ax.set_xticks(lay['xticks'])
    ax.set_xlabel(lay['xlabel'], color=INK); ax.set_ylabel('Response, ΔR/R (%)', color=INK)
    _axes(ax); ax.yaxis.grid(True, color=GRIDC, linewidth=0.6); ax.set_axisbelow(True)
    h, l = ax.get_legend_handles_labels(); order = [2, 0, 1, 3]
    ax.legend([h[i] for i in order], [l[i] for i in order], frameon=False, fontsize=7.5, loc='upper center', bbox_to_anchor=(0.45, -0.2), ncol=1, handlelength=2.2)
    fig.tight_layout(); _save(fig, stem)


def parity(out, name, stem):
    d = out['datasets'][name]; P = T.parity(out, name); M = d['metrics']
    form, model = d['paper_model']
    mb = M[(M.training_form == form) & (M.model == model)].iloc[0]
    mn = M[(M.training_form == 'all pairs') & M.model.str.startswith('No change')].iloc[0]
    vals = np.r_[P.measured_response_pct, P.predicted_response_pct, P.starting_response_pct]
    lo, hi = 10 ** np.floor(np.log10(vals.min())), 10 ** np.ceil(np.log10(vals.max()))
    fig, ax = plt.subplots(figsize=(3.8, 3.9), dpi=300)
    ax.plot([lo, hi], [lo, hi], color=INK2, linewidth=0.9, linestyle=(0, (4, 3)), label='y = x', zorder=1)
    ax.scatter(P.measured_response_pct, P.no_change_prediction_pct, s=20, facecolors='none', edgecolors=GREY, linewidths=0.9,
               label='No change (baseline)', zorder=2)
    ax.scatter(P.measured_response_pct, P.predicted_response_pct, s=20, color=BLUE, edgecolors='white', linewidths=0.5, label=model, zorder=3)
    ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(lo, hi); ax.set_ylim(lo, hi); ax.set_aspect('equal')
    plain = matplotlib.ticker.FuncFormatter(lambda v, _: f'{v:g}')
    ax.xaxis.set_major_formatter(plain); ax.yaxis.set_major_formatter(plain)
    ax.set_xlabel('Measured response (%)', color=INK); ax.set_ylabel('Predicted response (%)', color=INK)
    ax.text(0.04, 0.96, f'{model}: R² = {mb.R2_response:.2f}, RMSE = {mb.RMSE_response_pct:.1f}\n'
                        f'No change: R² = {mn.R2_response:.2f}, RMSE = {mn.RMSE_response_pct:.1f}\n'
                        f'{int(mb.n)} held-out points, papers hidden one at a time',
            transform=ax.transAxes, va='top', ha='left', fontsize=6.8, color=INK2)
    _axes(ax); ax.grid(True, which='major', color=GRIDC, linewidth=0.6); ax.set_axisbelow(True)
    ax.legend(frameon=False, fontsize=7.5, loc='upper center', bbox_to_anchor=(0.5, -0.17), ncol=1)
    fig.tight_layout(); _save(fig, stem)
