"""Training rows and the models (settings unchanged from the original humidity_ml.py / temperature_ml.py).

TASK    input  = starting value and new value of RH (or T), each divided by 100
        output = log10(response at the new value / response at the starting value), i.e. the change along a curve
FORMS   'all pairs'          every ordered pair of points within a curve; the model is made antisymmetric
                             (the change 30 -> 70% RH is minus the change 70 -> 30% RH)
        'from lowest point'  only pairs that start at the curve's lowest point (the same form as the tests), including
                             the zero-change pair of the lowest point with itself
WEIGHTS humidity, all pairs: every curve carries equal weight; humidity, from lowest point: weight 1 per row;
        temperature: every sensor carries equal weight, split equally over its curves and then over its rows.
"""
import itertools, warnings
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, HistGradientBoostingRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, RBF
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
warnings.filterwarnings('ignore')


def training_rows(curves, form, factor):
    """X (start, end), y (change in log10 response) and weights from padded curves (keys x_all, s_all)."""
    hum = factor == 'humidity'
    X, y, w = [], [], []
    units = {}
    for c in curves: units.setdefault(c['unit'], []).append(c)
    for u, ucs in units.items():
        n_c = len(ucs)
        for c in ucs:
            x, s = c['x_all'], c['s_all']
            idx = list(itertools.permutations(range(len(x)), 2)) if form == 'all pairs' else [(0, j) for j in range(len(x))]
            for i, j in idx:
                X.append((x[i], x[j])); y.append(s[j] - s[i])
                w.append(1.0 / len(idx) if hum else 1.0 / (n_c * len(idx)))
    w = np.array(w)
    if hum and form != 'all pairs': w = np.ones(len(w))
    return np.array(X), np.array(y), w * len(w) / w.sum()


class Model:
    """Base class. predict() makes all-pairs models antisymmetric: f(a, b) = (g(a, b) - g(b, a)) / 2."""
    stochastic = True
    settings = ''
    def __init__(self, form, factor):
        self.anti = form == 'all pairs'; self.factor = factor
    def predict(self, X):
        X = np.asarray(X, float)
        return 0.5 * (self._p(X) - self._p(X[:, ::-1])) if self.anti else self._p(X)


class NoChange(Model):
    name, stochastic = 'No change (baseline, not ML)', False
    settings = 'predicts zero change: every point keeps the starting response'
    def fit(self, X, y, w, seed): return self
    def _p(self, X): return np.zeros(len(X))


class Forest(Model):
    name = 'Random forest'
    settings = 'RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=seed, n_jobs=2)'
    def fit(self, X, y, w, seed):
        self.m = RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=seed, n_jobs=2).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)


class Boost(Model):
    name = 'Gradient boosting'
    settings = 'GradientBoostingRegressor(n_estimators=200, learning_rate=0.05, max_depth=2, min_samples_leaf=2, subsample=0.8, random_state=seed)'
    def fit(self, X, y, w, seed):
        self.m = GradientBoostingRegressor(n_estimators=200, learning_rate=0.05, max_depth=2, min_samples_leaf=2,
                                           subsample=0.8, random_state=seed).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)


class MonoBoost(Model):
    name = 'Gradient boosting, monotonic'
    settings = ('HistGradientBoostingRegressor(max_iter=200, learning_rate=0.05, max_depth=2, min_samples_leaf=2, '
                'monotonic_cst=[1, -1], random_state=seed): the response may only fall as humidity rises (humidity only)')
    def fit(self, X, y, w, seed):
        self.m = HistGradientBoostingRegressor(max_iter=200, learning_rate=0.05, max_depth=2, min_samples_leaf=2,
                                               monotonic_cst=[1, -1], random_state=seed).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)


class GP(Model):
    name, stochastic = 'Gaussian process', False
    settings = ('GaussianProcessRegressor(ConstantKernel(0.01, (1e-6, 10)) * RBF([l, l], (0.05, 10)), alpha=4e-4 / weight, '
                'n_restarts_optimizer=3, random_state=0); l = 0.3 humidity, 0.5 temperature')
    def fit(self, X, y, w, seed):
        ls = 0.3 if self.factor == 'humidity' else 0.5
        k = ConstantKernel(0.01, (1e-6, 10)) * RBF([ls, ls], (0.05, 10))
        self.m = GaussianProcessRegressor(k, alpha=4e-4 / w, n_restarts_optimizer=3, random_state=0).fit(X, y); return self
    def _p(self, X): return self.m.predict(X)


class SV(Model):
    name, stochastic = 'Support vector regression', False
    settings = "SVR(kernel='rbf', C=1.0, epsilon=0.005, gamma=2.0)"
    def fit(self, X, y, w, seed):
        self.m = SVR(kernel='rbf', C=1.0, epsilon=0.005, gamma=2.0).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)


class NN(Model):
    name = 'Neural network (8 hidden units)'
    settings = "MLPRegressor(hidden_layer_sizes=(8,), activation='tanh', solver='lbfgs', alpha=1e-3, max_iter=5000, random_state=seed)"
    def fit(self, X, y, w, seed):
        self.m = MLPRegressor(hidden_layer_sizes=(8,), activation='tanh', solver='lbfgs', alpha=1e-3, max_iter=5000,
                              random_state=seed).fit(X, y, sample_weight=w); return self
    def _p(self, X): return self.m.predict(X)


def get_models(factor):
    """Model classes in the original order; the monotonic model exists for humidity only."""
    return [NoChange, Forest, Boost, MonoBoost, GP, SV, NN] if factor == 'humidity' else [NoChange, Forest, Boost, GP, SV, NN]


def model_by_name(factor, name):
    for M in get_models(factor):
        if M.name == name: return M
    raise KeyError(f'no model {name!r} for {factor}')


def model_table(factor):
    import pandas as pd
    return pd.DataFrame([dict(model=M.name, random=('yes: one fit per seed' if M.stochastic else 'no: one fit'), settings=M.settings)
                         for M in get_models(factor)])
