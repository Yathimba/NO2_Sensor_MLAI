"""Write everything a run produces:
    results/excel/NO2_ML_datasets_and_tests.xlsx   datasets, hold-out test results, your sensor's predictions
    results/excel/NO2_ML_paper_R2_RMSE.xlsx        R2 / RMSE, parity, response curves, robustness (with charts)
    results/figures/*.png, *.pdf                   response curves and parity plots
    results/csv/tables/*.csv                       every Excel table as CSV
    results/csv/raw/*.csv                          per-seed predictions and other raw outputs
    results/run_info.json                          settings, software versions, run time, chosen models
"""
import json
from pathlib import Path
import numpy as np, pandas as pd
from .config import BASELINE
from . import tables as T, excel as X, figures as F
from .pipeline import PAPER_DATASETS


def _fmt_cfg(cfg): return f'{cfg[1]} ({cfg[0]} training)'


def readme_tests(out):
    s, info = out['settings'], out['run_info']
    ds = []
    for name, d in out['datasets'].items():
        r = d['runs']['main']; papers = len({c['paper'] for c in r['curves']})
        ds.append(f'{name}: {len(r["curves"])} curves from {papers} papers, {r["n_measured"]} measured + {r["n_rows"] - r["n_measured"]} '
                  f'interpolated = {r["n_rows"]} rows')
    excl = '; '.join(f'{k}: {", ".join(v) if v else "none"}' for k, v in s.exclude_papers.items())
    v = info['versions']
    return [
        ('what this file is', 'Hold-out test results of every model on every dataset, the datasets the models were trained on (measured plus '
                              'interpolated rows), and your sensor\'s predicted response. Produced by run_all.py or the notebook on '
                              f'{info["started"][:10]} ({info["minutes"]} min).'),
        ('datasets', '. '.join(ds) + '. temperature_local is temperature with 14 Kumar 2018 (Nanotechnology) pulses measured from their local baseline.'),
        ('papers left out', excl),
        ('interpolated rows', 'Rows with synthetic = 1 (grey) are not measurements: each response is read off a straight line, in log(response), '
                              'between the two measured neighbours on the same curve, so they add no information beyond the measured points. '
                              'New points fill the widest gaps first, so each curve ends up with roughly even spacing.'),
        ('tests', 'hide one paper: train on every other paper, predict the hidden paper (the fair test). hide one lab: hide every paper of one '
                  'institution together (stricter). hide one sensor: hide one sensor (temperature) or one curve (humidity). Each hidden curve is '
                  'predicted from its own lowest measured point; only measured points are scored.'),
        ('error_pct', 'Median over hidden points of (larger / smaller - 1) x 100, comparing predicted and measured response; median over '
                      f'{len(s.seeds)} seeds for random models. error_range_over_seeds gives the lowest and highest seed.'),
        ('R2_of_change', 'R2 of the predicted change log10(response / starting response) over all hidden points (median over seeds). '
                         'Below 0 means worse than predicting the average change.'),
        ('beats_no_change', 'yes if error_pct is lower than the no-change baseline (which predicts that every hidden point keeps its starting '
                            'response) in the same test, training form and row set.'),
        ('rows', '"measured only" = trained on measured points; "N rows" = trained on measured plus interpolated rows. Both are scored on '
                 'the same measured points.'),
        ('training forms', 'all pairs: every ordered pair of points within a curve, model made antisymmetric. from lowest point: only pairs '
                           'that start at a curve\'s lowest point (the same form as the tests).'),
        ('sheets', 'summary: best model per dataset and test. dataset_*: the training data. curves: what each curve is. models: model settings. '
                   'holdout_results: every test result. holdout_per_sensor: median error per hidden sensor. predictions_your_sensor: '
                   'predicted response of your sensor on a grid, every configuration, with the range over seeds.'),
        ('reading in code', "pandas.read_excel('results/excel/NO2_ML_datasets_and_tests.xlsx', sheet_name='holdout_results'); every sheet "
                            'is one table with its header in row 1. The same tables are in results/csv/tables.'),
        ('software', f'Python {v["python"]}, numpy {v["numpy"]}, pandas {v["pandas"]}, scikit-learn {v["scikit_learn"]}, scipy {v["scipy"]}.'),
    ]


def readme_paper(out, names):
    s = out['settings']
    rows = [
        ('what this file is', 'R2 and RMSE of the models reported in the paper (one per factor), the parity data behind them, your sensor\'s '
                              'predicted response curves, and two robustness checks. Every table can be plotted directly; charts are included '
                              'on the charts, parity_* and curve_* sheets.'),
        ('paper models', '; '.join(f'{n}: {_fmt_cfg(out["datasets"][n]["paper_model"])}, chosen by {out["datasets"][n]["paper_model_rule"]}' for n in names)),
        ('how R2 and RMSE are computed', 'Only on measured points of papers the model never saw (hide-one-paper test), each predicted from its '
                                         'curve\'s lowest measured point, using the median prediction over seeds. "response" compares predicted and '
                                         'measured responses in %, as in a parity plot. "change" compares predicted and measured log10(response / '
                                         'starting response); it is scale-free and is the honest measure of skill.'),
        ('read against no change', 'The no-change baseline (grey rows) predicts that each hidden curve keeps its starting response. Because the '
                                   'sensors differ greatly in size, it already scores a high R2 on response values; a model adds skill only where '
                                   'it beats that row.'),
    ]
    for n in names:
        d = out['datasets'][n]; M = d['metrics']; f, m = d['paper_model']
        b = M[(M.training_form == f) & (M.model == m)].iloc[0]; z = M[(M.training_form == 'all pairs') & (M.model == BASELINE)].iloc[0]
        txt = (f'{m} ({f} training): R2 = {b.R2_response:.2f} on response values (no change {z.R2_response:.2f}); RMSE = {b.RMSE_response_pct:.1f} '
               f'% points (no change {z.RMSE_response_pct:.1f}); R2 of the change = {b.R2_change:.2f} (no change {z.R2_change:.2f}); median miss '
               f'{b.median_miss_pct:.1f}% (no change {z.median_miss_pct:.1f}%); {int(b.n)} held-out points.')
        R = d['runs']['main']['results']
        lab = R[(R.test == 'hide one lab') & R.training.str.endswith(f) & (R.model == m)]
        labz = R[(R.test == 'hide one lab') & R.training.str.endswith('all pairs') & (R.model == BASELINE)]
        if len(lab):
            txt += f' When whole labs are hidden its median miss is {lab.error_pct.iloc[0]:.1f}% (no change {labz.error_pct.iloc[0]:.1f}%).'
        if 'leave_one_paper_out' in d:
            Lo = d['leave_one_paper_out']; ref = 80 if d['factor'] == 'humidity' else 100
            q = Lo[(Lo.training_form == f) & (Lo.model == m) & (Lo.x == ref)]
            full = float(q[q.paper_left_out == 'none'].response_pct.iloc[0]); others = q[q.paper_left_out != 'none']
            far = others.loc[(others.response_pct - full).abs().idxmax()]
            unit = '% RH' if d['factor'] == 'humidity' else ' C'
            txt += (f' Leaving one training paper out moves its prediction at {ref}{unit} from {full:.1f}% to between {others.response_pct.min():.1f}% '
                    f'and {others.response_pct.max():.1f}% (largest change without {far.paper_left_out}).')
        rows.append((f'{n} result', txt))
    a = out['datasets'][names[0]]['anchor']
    excl = '; '.join(f'{k}: ' + (', '.join(f'{c[1]} ({c[0]})' for c in v) if v else 'none') for k, v in s.band_exclude.items())
    rows += [
        ('your sensor', f'Every prediction starts from your measured {a["response"]:g}% ({a["NO2_ppm"]:g} ppm NO2, {a["light"]}, {a["source"]}), placed at '
                        f'{a["RH"]:g}% RH and {a["T"]:g} C ({a["T"] + 273:g} K). Your Methods state 300 K but only "ambient" humidity; the {a["RH"]:g}% RH '
                        'comes from the manuscript\'s old ML section, so confirm it. Nothing about your sensor is used in training.'),
        ('band in the curve charts', f'Lowest to highest of all model configurations except those set in Settings.band_exclude ({excl}), which are '
                                     'numerically unstable; they stay in every table.'),
        ('caveats', 'Every training curve comes from other sensors, none of them yours. All temperature sweeps were measured in the dark. '
                    'Interpolated rows are not measurements; say so if you report the row count.'),
        ('sheets', 'metrics: R2 and RMSE of every configuration (blue = paper model, grey = baseline). chart_data and charts: bar charts of '
                   'metrics. parity_*: held-out points of the paper model. curve_*: predicted response of your sensor, every configuration. '
                   'robustness_tests: hide one paper vs hide one lab. robustness_leave_one_out: your sensor\'s prediction with one training paper '
                   'left out. chart_helpers: the y = x lines of the parity charts.'),
        ('reading in code', "pandas.read_excel('results/excel/NO2_ML_paper_R2_RMSE.xlsx', sheet_name='metrics'); the same tables are in "
                            'results/csv/tables.'),
    ]
    return rows


def save_all(out, log=print):
    s = out['settings']; root = Path(s.out_dir)
    for sub in ('excel', 'figures', 'csv/tables', 'csv/raw'): (root / sub).mkdir(parents=True, exist_ok=True)
    names = [n for n in PAPER_DATASETS if n in out['datasets'] and 'paper_model' in out['datasets'][n]]

    # raw outputs
    for name, d in out['datasets'].items():
        for key, run in d['runs'].items():
            tag = 'measured_only' if run['n_rows'] == run['n_measured'] else f'{run["n_rows"]}_rows'
            run['predictions'].to_csv(root / f'csv/raw/{name}__{tag}__holdout_predictions_per_seed.csv', index=False)
            run['results'].to_csv(root / f'csv/raw/{name}__{tag}__holdout_results_wide.csv', index=False)
        d['sensor_grid'].to_csv(root / f'csv/raw/{name}__sensor_predictions_grid.csv', index=False)
        d['sensor_fine'].to_csv(root / f'csv/raw/{name}__sensor_predictions_fine.csv', index=False)
        if 'heldout_points' in d: d['heldout_points'].to_csv(root / f'csv/raw/{name}__heldout_points_paper_test.csv', index=False)
        if 'leave_one_paper_out' in d: d['leave_one_paper_out'].to_csv(root / f'csv/raw/{name}__leave_one_paper_out.csv', index=False)

    # tidy tables (the same as the Excel sheets)
    tabs = {'summary': T.summary(out), 'curves': T.curves(out), 'holdout_results': T.holdout_results(out),
            'holdout_per_sensor': T.holdout_per_sensor(out), 'predictions_your_sensor': T.predictions(out)}
    for name, D in T.datasets(out).items(): tabs[f'dataset_{name}'] = D
    if names:
        tabs['metrics'] = T.metrics(out, names)
        tabs['robustness_tests'] = T.robustness_tests(out, names)
        tabs['robustness_leave_one_out'] = T.leave_one_paper_out(out, names)
        for n in names:
            tabs[f'parity_{n}'] = T.parity(out, n)
            tabs[f'curve_{n}'] = T.curve_wide(out, n, s.band_exclude.get(out['datasets'][n]['factor'], []))[0]
    for k, D in tabs.items():
        if len(D): D.to_csv(root / f'csv/tables/{k}.csv', index=False)

    X.tests_workbook(out, root / 'excel/NO2_ML_datasets_and_tests.xlsx', readme_tests(out))
    log(f'  wrote {root / "excel/NO2_ML_datasets_and_tests.xlsx"}')
    if names:
        X.paper_workbook(out, root / 'excel/NO2_ML_paper_R2_RMSE.xlsx', readme_paper(out, names), names, s.band_exclude)
        log(f'  wrote {root / "excel/NO2_ML_paper_R2_RMSE.xlsx"}')
        for n in names:
            fac = out['datasets'][n]['factor']
            F.response_curve(out, n, s.band_exclude.get(fac, []), str(root / f'figures/{fac}_vs_response'))
            F.parity(out, n, str(root / f'figures/parity_{fac}'))
        log(f'  wrote figures to {root / "figures"}')
    (root / 'run_info.json').write_text(json.dumps(out['run_info'], indent=2, default=str))
