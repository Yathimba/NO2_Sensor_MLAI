"""Run the whole analysis: every dataset, hold-out test and model, then the outputs used in the paper.

    from no2ml import Settings, run_all
    out = run_all(Settings())            # about 45 minutes on 2 CPU cores with the default settings
"""
import time, platform, datetime
import numpy as np, pandas as pd
from .config import Settings, DATASETS, GRID, FINE_GRID, ROBUST_GRID
from . import data as D
from .models import get_models
from .evaluate import run_tests, summarize, heldout_points, metrics, select_paper_model
from .predict import sensor_predictions, leave_one_paper_out

PAPER_DATASETS = ('humidity', 'temperature')          # the two models reported in the paper
SET_LABEL = {'humidity': 'B: every humidity curve', 'temperature': 'B: every temperature sweep'}


def prepare(name, data, settings):
    """Readings, curves, models and anchor of one dataset (no training yet)."""
    spec = DATASETS[name]; factor = spec['factor']
    df = D.readings(data, factor, spec['variant'])
    curves = D.build_curves(df, factor, settings.exclude_papers.get(factor, []))
    anc = D.anchor(data, settings.anchor_row_id)
    return dict(name=name, factor=factor, label=spec['label'], readings=df, curves=curves, models=get_models(factor), anchor=anc,
                anchor_x=(anc['RH'] if factor == 'humidity' else anc['T']) / 100, anchor_s=anc['response'])


def run_holdout(prep, settings, n_total, log=print):
    """Pad the curves to n_total rows and run every hold-out test. Returns the padded curves, the dataset table,
    the per-point predictions (every seed) and the results table."""
    curves = D.pad_curves(prep['curves'], n_total)
    n_meas = sum(len(c['x']) for c in curves); n_all = sum(len(c['x_all']) for c in curves)
    label = 'measured' if n_all == n_meas else f'measured + interpolated ({n_all} rows)'
    log(f'  {prep["name"]}: {len(curves)} curves, {n_meas} measured + {n_all - n_meas} interpolated = {n_all} rows')
    t0 = time.time()
    pred = run_tests(curves, prep['factor'], prep['models'], list(settings.seeds), settings.tests, log if settings.verbose else None)
    res = summarize(pred, curves, prep['models'], SET_LABEL[prep['factor']], label)
    log(f'    hold-out tests done in {time.time() - t0:.0f} s')
    return dict(n_total=n_total, n_rows=n_all, n_measured=n_meas, label=label, curves=curves,
                dataset=D.dataset_table(curves, prep['factor']), predictions=pred, results=res)


def run_dataset(name, data, settings, log=print):
    t0 = time.time()
    prep = prepare(name, data, settings)
    runs = {}
    if settings.compare_measured_only and settings.n_total:
        runs['measured'] = run_holdout(prep, settings, 0, log)
    runs['main'] = run_holdout(prep, settings, settings.n_total, log)
    main = runs['main']
    out = dict(name=name, factor=prep['factor'], label=prep['label'], anchor=prep['anchor'], runs=runs,
               curve_table=D.curve_table(prep['curves'], prep['factor']))
    seeds = list(settings.seeds)
    out['sensor_grid'], out['sensor_fine'] = sensor_predictions(main['curves'], prep['factor'], prep['models'], seeds,
                                                               prep['anchor_x'], prep['anchor_s'], GRID[prep['factor']], FINE_GRID[prep['factor']])
    if 'paper' in settings.tests:
        out['heldout_points'] = heldout_points(main['predictions'])
        out['points'], out['metrics'] = metrics(out['heldout_points'])
        pm = settings.paper_model.get(prep['factor'])
        out['paper_model'] = tuple(pm) if pm else select_paper_model(main['results'])
        out['paper_model_rule'] = 'set in Settings.paper_model' if pm else 'lowest median error, hide-one-paper test'
        if name in PAPER_DATASETS:
            configs = [out['paper_model']] + [tuple(c) for c in settings.robustness_models if tuple(c) != out['paper_model']]
            out['leave_one_paper_out'] = leave_one_paper_out(main['curves'], prep['factor'], configs, seeds, prep['anchor_x'],
                                                             prep['anchor_s'], ROBUST_GRID[prep['factor']], log if settings.verbose else None)
    out['seconds'] = time.time() - t0
    log(f'  {name}: finished in {out["seconds"] / 60:.1f} min' + (f'; paper model {out["paper_model"][1]}, {out["paper_model"][0]}' if 'paper_model' in out else ''))
    return out


def versions():
    import sklearn, scipy, openpyxl, matplotlib
    return dict(python=platform.python_version(), numpy=np.__version__, pandas=pd.__version__, scikit_learn=sklearn.__version__,
                scipy=scipy.__version__, openpyxl=openpyxl.__version__, matplotlib=matplotlib.__version__, platform=platform.platform())


def run_all(settings=None, log=print):
    """Every dataset in settings.datasets; writes the outputs if settings.write_outputs."""
    settings = settings or Settings()
    t0 = time.time()
    started = datetime.datetime.now().isoformat(timespec='seconds')
    log(f'NO2 sensor ML pipeline: {", ".join(settings.datasets)}; {settings.n_total} rows; tests {", ".join(settings.tests)}; '
        f'{len(settings.seeds)} seeds')
    data = D.load_data(settings.data_file)
    out = dict(settings=settings, data=data, datasets={})
    for name in settings.datasets:
        log(f'[{name}]')
        out['datasets'][name] = run_dataset(name, data, settings, log)
    out['run_info'] = dict(started=started, finished=datetime.datetime.now().isoformat(timespec='seconds'),
                           minutes=round((time.time() - t0) / 60, 1), versions=versions(), settings=settings.as_dict(),
                           paper_models={k: list(v['paper_model']) for k, v in out['datasets'].items() if 'paper_model' in v})
    if settings.write_outputs:
        from .outputs import save_all
        save_all(out, log)
    log(f'done in {(time.time() - t0) / 60:.1f} min')
    return out
