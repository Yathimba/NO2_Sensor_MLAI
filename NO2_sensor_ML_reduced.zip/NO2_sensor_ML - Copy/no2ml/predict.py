"""Predictions for your sensor, and the leave-one-paper-out robustness check of those predictions.

Every model is trained on all curves of a dataset and asked for the change from your measured point (e.g. 20% RH) to each
grid value; the predicted response is your measured value x 10^change. Nothing about your sensor is used in training.
"""
import numpy as np, pandas as pd
from .models import training_rows, model_by_name
from .config import FORMS


def _seeds(M, seeds):
    return seeds if M.stochastic else [0]


def sensor_predictions(curves, factor, models, seeds, anchor_x, anchor_s, grid, fine_grid):
    """Coarse grid: median, lowest and highest over seeds. Fine grid: median over seeds (for figures and curve sheets).
    anchor_x is the anchor's RH or T divided by 100; anchor_s its response in %."""
    g = np.array(grid) / 100; gf = np.array(fine_grid) / 100
    coarse, fine = [], []
    for form in FORMS:
        X, y, w = training_rows(curves, form, factor)
        for M in models[1:]:
            Pc, Pf = [], []
            for sd in _seeds(M, seeds):
                m = M(form, factor).fit(X, y, w, sd)
                Pc.append(anchor_s * 10 ** m.predict(np.c_[np.full(len(g), anchor_x), g]))
                Pf.append(anchor_s * 10 ** m.predict(np.c_[np.full(len(gf), anchor_x), gf]))
            Pc, Pf = np.array(Pc), np.array(Pf)
            for i, v in enumerate(grid):
                coarse.append(dict(training_form=form, model=M.name, x=v, response_pct=float(np.median(Pc[:, i])),
                                   low_over_seeds=float(Pc[:, i].min()), high_over_seeds=float(Pc[:, i].max())))
            for i, v in enumerate(fine_grid):
                fine.append(dict(training_form=form, model=M.name, x=int(v), response_pct=float(np.median(Pf[:, i]))))
    return pd.DataFrame(coarse), pd.DataFrame(fine)


def leave_one_paper_out(curves, factor, configs, seeds, anchor_x, anchor_s, grid, log=None):
    """Your sensor's predicted response with each training paper left out in turn (refit on the rest).
    Shows how much a prediction rests on a single paper."""
    g = np.array(grid) / 100
    papers = list(dict.fromkeys(c['paper'] for c in curves))
    rows = []
    for form, name in configs:
        M = model_by_name(factor, name)
        for left in ['none'] + papers:
            cs = curves if left == 'none' else [c for c in curves if c['paper'] != left]
            X, y, w = training_rows(cs, form, factor)
            P = np.array([anchor_s * 10 ** M(form, factor).fit(X, y, w, sd).predict(np.c_[np.full(len(g), anchor_x), g]) for sd in _seeds(M, seeds)])
            med = np.median(P, axis=0)
            for v, r in zip(grid, med):
                rows.append(dict(training_form=form, model=name, paper_left_out=left, x=v, response_pct=float(r)))
        if log: log(f'      leave-one-paper-out | {form:17s} | {name}')
    return pd.DataFrame(rows)
