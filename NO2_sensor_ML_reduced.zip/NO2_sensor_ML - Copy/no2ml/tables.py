"""Tidy tables (one table per sheet, header in row 1) built from a pipeline run. The Excel workbooks and CSV copies use these."""
import numpy as np, pandas as pd
from .config import BASELINE, DATASETS

RUN_NAME = {'measured': 'measured only', 'main': None}       # 'main' is labelled by its row count, e.g. '100 rows'
FIXED = ['set', 'test', 'training', 'model', 'error_pct', 'error_range_over_seeds', 'worst_point_pct', 'R2_of_change']


def rows_label(run):
    return 'measured only' if run['n_rows'] == run['n_measured'] else f'{run["n_rows"]} rows'


def holdout_results(out):
    """Every dataset, row set, test, training form and model, with whether it beats the no-change baseline."""
    parts = []
    for name, d in out['datasets'].items():
        for key, run in d['runs'].items():
            R = run['results'].copy()
            R['form'] = R.training.str.split(', ').str[-1]
            base = R[R.model == BASELINE].set_index(['test', 'form']).error_pct
            beats = [('baseline' if m == BASELINE else ('yes' if e < base[(t, f)] else 'no')) for m, e, t, f in zip(R.model, R.error_pct, R.test, R.form)]
            parts.append(pd.DataFrame(dict(dataset=name, rows=rows_label(run), test=R.test, training_form=R.form, model=R.model,
                                           error_pct=R.error_pct, error_range_over_seeds=R.error_range_over_seeds,
                                           worst_point_pct=R.worst_point_pct, R2_of_change=R.R2_of_change, beats_no_change=beats)))
    return pd.concat(parts, ignore_index=True)


def holdout_per_sensor(out):
    """Median error per hidden sensor (humidity: per curve), long format."""
    parts = []
    for name, d in out['datasets'].items():
        for key, run in d['runs'].items():
            R = run['results']
            units = [c for c in R.columns if c not in FIXED]
            L = R[['test', 'training', 'model'] + units].melt(id_vars=['test', 'training', 'model'], value_vars=units, var_name='sensor',
                                                               value_name='error_pct')
            L.insert(0, 'rows', rows_label(run)); L.insert(0, 'dataset', name)
            L['training_form'] = L.training.str.split(', ').str[-1]
            parts.append(L[['dataset', 'rows', 'test', 'training_form', 'model', 'sensor', 'error_pct']])
    return pd.concat(parts, ignore_index=True)


def summary(out):
    """Per dataset and test: the no-change error, the best model and how many models beat no change."""
    H = holdout_results(out)
    rows = []
    for name, d in out['datasets'].items():
        main = rows_label(d['runs']['main'])
        for test in dict.fromkeys(H[H.dataset == name].test):
            g = H[(H.dataset == name) & (H.test == test) & (H.rows == main)]
            base = g[g.model == BASELINE].error_pct.iloc[0]; mods = g[g.model != BASELINE]
            b = mods.loc[mods.error_pct.idxmin()]
            rec = dict(dataset=name, test=test, rows=main, no_change_error_pct=base, best_model=b.model, best_training_form=b.training_form,
                       best_error_pct=b.error_pct, models_beating_no_change=f'{int((mods.error_pct < base).sum())} of {len(mods)}')
            if 'measured' in d['runs']:
                gm = H[(H.dataset == name) & (H.test == test) & (H.rows == 'measured only')]
                mm = gm[gm.model != BASELINE]; bm = mm.loc[mm.error_pct.idxmin()]
                rec.update(measured_only_best_model=f'{bm.model}, {bm.training_form}', measured_only_best_error_pct=bm.error_pct,
                           measured_only_models_beating_no_change=f'{int((mm.error_pct < base).sum())} of {len(mm)}')
            rows.append(rec)
    return pd.DataFrame(rows)


def datasets(out):
    """The padded datasets (measured + interpolated rows), one table per dataset."""
    return {name: d['runs']['main']['dataset'] for name, d in out['datasets'].items()}


def curves(out):
    parts = []
    for name, d in out['datasets'].items():
        c = d['curve_table'].copy(); c.insert(0, 'dataset', name); parts.append(c)
    return pd.concat(parts, ignore_index=True)


def predictions(out):
    """Your sensor's predicted response on the coarse grid, every configuration, with the range over seeds."""
    parts = []
    for name, d in out['datasets'].items():
        P = d['sensor_grid'].copy()
        P.insert(0, 'dataset', name)
        P.insert(3, 'x_name', 'RH_pct' if d['factor'] == 'humidity' else 'T_C')
        parts.append(P)
    return pd.concat(parts, ignore_index=True)


def metrics(out, names):
    parts = []
    for name in names:
        d = out['datasets'][name]
        M = d['metrics'].copy()
        M.insert(0, 'dataset', name)
        M['paper_model'] = ['yes' if (f, m) == d['paper_model'] else '' for f, m in zip(M.training_form, M.model)]
        M['baseline'] = ['yes' if m == BASELINE else '' for m in M.model]
        parts.append(M.rename(columns={'n': 'held_out_points'}))
    order = ['dataset', 'training_form', 'model', 'held_out_points', 'R2_response', 'RMSE_response_pct', 'R2_change', 'RMSE_change_log10',
             'RMSE_change_factor', 'median_miss_pct', 'paper_model', 'baseline']
    return pd.concat(parts, ignore_index=True)[order]


def parity(out, name):
    """Held-out points of the paper model (hide-one-paper test), with the no-change prediction for comparison."""
    d = out['datasets'][name]; P = d['points']
    b = P[(P.training_form == d['paper_model'][0]) & (P.model == d['paper_model'][1])]
    xs = 'RH_pct' if d['factor'] == 'humidity' else 'T_C'
    return pd.DataFrame({'curve': b.curve, 'paper': b.paper, f'{xs}_start': b.x_start, xs: b.x, 'starting_response_pct': b.S_start,
                         'measured_response_pct': b.S_meas, 'predicted_response_pct': b.S_pred, 'no_change_prediction_pct': b.S_start,
                         'measured_ratio_to_start': 10 ** b.true_change, 'predicted_ratio_to_start': 10 ** b.pred_change}).reset_index(drop=True)


def curve_wide(out, name, band_exclude):
    """Fine-grid prediction for your sensor: paper model, band (lowest to highest of the configurations not excluded),
    no-change line, measured anchor, and every configuration."""
    d = out['datasets'][name]
    W = d['sensor_fine'].pivot_table(index='x', columns=['training_form', 'model'], values='response_pct', sort=False)
    keep = [c for c in W.columns if tuple(c) not in [tuple(e) for e in band_exclude]]
    hum = d['factor'] == 'humidity'
    a = d['anchor']; ax = int(round(a['RH'] if hum else a['T']))
    T = pd.DataFrame({'RH_pct' if hum else 'T_C': W.index.astype(int)})
    if not hum: T['T_K'] = T.T_C + 273
    T['paper_model'] = W[d['paper_model']].values
    T['band_low'] = W[keep].min(axis=1).values; T['band_high'] = W[keep].max(axis=1).values
    T['no_change'] = a['response']
    T['measured'] = [a['response'] if int(v) == ax else np.nan for v in W.index]
    for f, m in W.columns: T[f'{m} | {f}'] = W[(f, m)].values
    return T, len(keep)


def robustness_tests(out, names):
    """Median error and R2 of change per configuration when single papers vs whole labs are hidden (main row set)."""
    parts = []
    for name in names:
        d = out['datasets'][name]; R = d['runs']['main']['results'].copy()
        R['form'] = R.training.str.split(', ').str[-1]
        tests = set(R.test)
        if not {'hide one paper', 'hide one lab'} <= tests: continue
        p = R[R.test == 'hide one paper'].set_index(['form', 'model']); l = R[R.test == 'hide one lab'].set_index(['form', 'model'])
        for (f, m) in p.index:
            parts.append(dict(dataset=name, training_form=f, model=m, error_pct_hide_one_paper=p.loc[(f, m), 'error_pct'],
                              error_pct_hide_one_lab=l.loc[(f, m), 'error_pct'], R2_of_change_hide_one_paper=p.loc[(f, m), 'R2_of_change'],
                              R2_of_change_hide_one_lab=l.loc[(f, m), 'R2_of_change'], paper_model='yes' if (f, m) == d['paper_model'] else ''))
    return pd.DataFrame(parts)


def leave_one_paper_out(out, names):
    parts = []
    for name in names:
        d = out['datasets'][name]
        if 'leave_one_paper_out' not in d: continue
        L = d['leave_one_paper_out'].copy(); L.insert(0, 'dataset', name)
        L.insert(4, 'x_name', 'RH_pct' if d['factor'] == 'humidity' else 'T_C')
        parts.append(L)
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
