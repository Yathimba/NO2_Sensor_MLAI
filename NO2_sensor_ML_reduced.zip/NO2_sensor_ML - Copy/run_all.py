"""Run the whole NO2 sensor ML analysis from the command line and write every result to results/.

    python run_all.py                       full run with the default settings (about 45 minutes on 2 CPU cores)
    python run_all.py --check               ... and compare the results with the stored reference run
    python run_all.py --quick               fast smoke test (2 seeds, hide-one-paper only); numbers differ from the full run
    python run_all.py --exclude-humidity    keep every humidity paper (by default Chen 2021 is left out)
    python run_all.py --humidity-model "all pairs|Support vector regression"     report this model instead of the automatic choice

See README.md for what each output holds.
"""
import argparse, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))      # so 'no2ml' is found from any working folder
from no2ml import Settings, run_all


def cfg(s):
    if s is None: return None
    form, model = [p.strip() for p in s.split('|')]
    return (form, model)


def main(argv=None):
    p = argparse.ArgumentParser(description='NO2 sensor ML: train, test and report the humidity and temperature models.')
    p.add_argument('--datasets', nargs='+', choices=['humidity', 'temperature', 'temperature_local'], help='datasets to run (default: all three)')
    p.add_argument('--n-total', type=int, help='rows per dataset after interpolation (default 100; 0 = measured points only)')
    p.add_argument('--seeds', type=int, help='number of random seeds (default 10)')
    p.add_argument('--tests', nargs='+', choices=['paper', 'lab', 'sensor'], help='hold-out tests (default: paper lab sensor)')
    p.add_argument('--exclude-humidity', nargs='*', metavar='PAPER', help='humidity papers to leave out (default: "Chen 2021"; give none to keep all)')
    p.add_argument('--exclude-temperature', nargs='*', metavar='PAPER', help='temperature papers to leave out (default: none)')
    p.add_argument('--humidity-model', help='model reported for humidity, as "training form|model name" (default: lowest hide-one-paper error)')
    p.add_argument('--temperature-model', help='model reported for temperature, same format')
    p.add_argument('--no-measured-only', action='store_true', help='skip the measured-only comparison runs')
    p.add_argument('--out', help='output folder (default: results)')
    p.add_argument('--quick', action='store_true', help='2 seeds and the hide-one-paper test only, for a quick check of the code')
    p.add_argument('--check', action='store_true', help='compare the results with tests/expected after the run')
    a = p.parse_args(argv)

    s = Settings()
    if a.datasets: s.datasets = tuple(a.datasets)
    if a.n_total is not None: s.n_total = a.n_total
    if a.seeds: s.seeds = tuple(range(a.seeds))
    if a.tests: s.tests = tuple(a.tests)
    if a.exclude_humidity is not None: s.exclude_papers['humidity'] = list(a.exclude_humidity)
    if a.exclude_temperature is not None: s.exclude_papers['temperature'] = list(a.exclude_temperature)
    if a.humidity_model: s.paper_model['humidity'] = cfg(a.humidity_model)
    if a.temperature_model: s.paper_model['temperature'] = cfg(a.temperature_model)
    if a.no_measured_only: s.compare_measured_only = False
    if a.out: s.out_dir = Path(a.out)
    if a.quick: s.seeds = (0, 1); s.tests = ('paper',); s.compare_measured_only = False
    run_all(s)

    if a.check:
        from no2ml.check import compare
        R, ok = compare(Path(s.out_dir) / 'csv' / 'tables')
        print(R.to_string(index=False))
        print('REPRODUCED' if ok else 'DIFFERENCES FOUND (see above)')
        return 0 if ok else 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
