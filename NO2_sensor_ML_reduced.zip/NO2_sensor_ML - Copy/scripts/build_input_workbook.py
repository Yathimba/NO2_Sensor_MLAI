"""Build data/NO2_sensor_data.xlsx, the single input file of the pipeline, from the raw workbooks.

    python scripts/build_input_workbook.py

Inputs (data/raw/):
    NO2_humidity_temperature_datasets_checked.xlsx    the dataset after the independent check (verified, check_note columns)
    NO2_humidity_temperature_datasets_as_received.xlsx the dataset as first delivered (used only to confirm the values are identical)
    kumar2018_local_baselines.csv                      local-baseline values for 14 Kumar 2018 (Nanotechnology) pulses
Output: data/NO2_sensor_data.xlsx. Every sheet is one table with its header in row 1 (no merged cells, no formulas),
so it can be read by people in Excel and by code with pandas.read_excel(path, sheet_name=...).
"""
from pathlib import Path
import numpy as np, pandas as pd, openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data' / 'raw'
OUT = ROOT / 'data' / 'NO2_sensor_data.xlsx'
CHECKED = RAW / 'NO2_humidity_temperature_datasets_checked.xlsx'
RECEIVED = RAW / 'NO2_humidity_temperature_datasets_as_received.xlsx'
LOCAL = RAW / 'kumar2018_local_baselines.csv'


def unified_response(r):
    c, v = r.conversion, r.published_value
    if c == 'from Ra and Rg': return (max(r.Ra, r.Rg) / min(r.Ra, r.Rg) - 1) * 100
    if c == 'ratio': return (v - 1) * 100
    if c == 'percent (resistance falls)': return v / (100 - v) * 100
    if c == 'fraction': return v * 100
    if c == 'as published': return v
    raise ValueError(f'row {r.row_id}: unknown conversion {c!r}')


def read(path, sheet):
    d = pd.read_excel(path, sheet_name=sheet)
    return d[d.row_id.notna()].reset_index(drop=True)


sheets = {}
for new, old in (('humidity', 'humidity_B'), ('temperature', 'temperature_B'), ('your_sensor', 'your_sensor')):
    d, r = read(CHECKED, old), read(RECEIVED, old)
    core = [c for c in r.columns if c not in ('response_pct', 'verified')]
    pd.testing.assert_frame_equal(d[core], r[core], check_dtype=False)        # the check changed no reading
    d['row_id'] = d.row_id.astype(int)
    d['response_pct'] = d.apply(unified_response, axis=1)
    sheets[new] = d
    print(f'{new}: {len(d)} rows, identical readings in the checked and as-received workbooks')

# local baselines: the second and later pulses of two Kumar 2018 (Nanotechnology) sensors started from an unrecovered
# baseline; the local-baseline value measures each pulse from the resistance just before it.
L = pd.read_csv(LOCAL)
chk = ((1 + L.published_value_as_delivered / 100) / (1 + L.baseline_offset_pct / 100) - 1) * 100
assert np.allclose(chk.round(2), L.published_value_local_baseline), 'local-baseline values do not follow from the offsets'
T = sheets['temperature']
T = T.merge(L[['row_id', 'baseline_offset_pct', 'published_value_local_baseline']], on='row_id', how='left')
m = T.published_value_local_baseline.notna()
assert np.allclose(T.loc[m, 'published_value'], L.set_index('row_id').loc[T.loc[m, 'row_id'], 'published_value_as_delivered'].values)
assert (T.loc[m, 'conversion'] == 'as published').all()
sheets['temperature'] = T
print(f'temperature: {int(m.sum())} rows carry a local-baseline alternative')

# sources: the papers table of the checked workbook, with the live row counts replaced by values
wb = openpyxl.load_workbook(CHECKED)
ws = wb['sources']
rows = [[c.value for c in r] for r in ws.iter_rows(min_row=5)]
src = []
for r in rows:
    if not r[0] or r[0] == 'Total': continue
    p = r[0]
    def cnt(df, used=False): return int(((df.paper == p) & ((df.use_in_model == 1) if used else True)).sum())
    src.append(dict(paper=p, used_for=r[1], reference=r[2], doi=r[3], sensor_and_conditions=r[4], figures_used=r[5],
                    humidity_rows=cnt(sheets['humidity']), humidity_rows_used=cnt(sheets['humidity'], True),
                    temperature_rows=cnt(sheets['temperature']), temperature_rows_used=cnt(sheets['temperature'], True),
                    status=r[12], comment=r[13]))
S = pd.DataFrame(src)

CONV = pd.DataFrame([
    ('from Ra and Rg', 'baseline Ra and resistance in gas Rg, read from a resistance curve', '(max(Ra, Rg) / min(Ra, Rg) - 1) x 100'),
    ('ratio', 'a ratio Rg/Ra or Ra/Rg, larger than 1', '(value - 1) x 100'),
    ('percent (resistance falls)', '(Ra - Rg)/Ra x 100 for a sensor whose resistance falls', 'value / (100 - value) x 100'),
    ('fraction', '(Rg - Ra)/Ra as a fraction, resistance rises', 'value x 100'),
    ('as published', '(Rg - Ra)/Ra x 100 with resistance rising, or a current-based response already equal to the unified one', 'value'),
], columns=['conversion', 'what was read from the paper', 'formula for response_pct'])

COLS = pd.DataFrame([
    ('row_id', 'Running number of the reading (same numbers as in the raw workbooks).', 'yes (identifies rows)'),
    ('paper', 'Short name of the source paper. Whole papers are hidden together in the hide-one-paper test.', 'yes'),
    ('device_id', 'One physical sensor (or one state of it). Changes are only ever computed within a device.', 'yes'),
    ('lab', 'Institution of the authors; all papers of a lab are hidden together in the hide-one-lab test.', 'yes'),
    ('material', 'Sensing layer.', 'no'),
    ('has_Au', '1 if the layer carries gold nanoparticles.', 'no'),
    ('other_component', 'Any third component, e.g. SnS.', 'no'),
    ('resistance_change', 'rises or falls on NO2 exposure.', 'no'),
    ('source', 'Figure, table or text the value came from.', 'no'),
    ('series', 'One name per figure panel or run. Humidity curves are device_id + series.', 'yes (humidity curves)'),
    ('sweep_of', 'humidity or temperature: which sweep the row belongs to.', 'yes (filter)'),
    ('NO2_ppm', 'NO2 concentration in ppm (50 ppb = 0.05). Temperature curves are device_id + NO2_ppm.', 'yes (temperature curves)'),
    ('light_on', '1 if the sensor was illuminated during the test.', 'no (label only)'),
    ('light_source / light_mW_cm2', 'Lamp and its intensity where stated.', 'no'),
    ('RH_pct', 'Relative humidity in %. Input of the humidity model.', 'yes (humidity)'),
    ('RH_basis', 'Where the RH number comes from (stated, dry air, assumed).', 'no'),
    ('T_C', 'Sensor temperature in C. Input of the temperature model.', 'yes (temperature)'),
    ('Ra / Rg / R_unit', 'Baseline resistance and resistance in gas, for readings taken from a resistance curve.', 'yes (conversion)'),
    ('published_value / published_definition', 'The value in the paper\'s own definition, for readings taken as a response value.', 'yes (conversion)'),
    ('conversion', 'Which of the five rules on the conversions sheet turns the reading into response_pct.', 'yes'),
    ('response_pct', 'Unified response S = (R_high / R_low - 1) x 100, computed from the reading and its conversion rule. '
                     'The code recomputes it and stops if this column disagrees.', 'yes (target)'),
    ('extraction', 'How the reading was obtained (digitised figure, table, text).', 'no'),
    ('est_uncertainty_pct', 'Estimated reading error, % of the value.', 'no'),
    ('use_in_model', '1 = used for training and testing; 0 = kept for the record (reason in excluded_because). '
                     'Papers excluded in a particular analysis (e.g. Chen 2021) are set in the code settings, not here.', 'yes (filter)'),
    ('excluded_because', 'Reason for use_in_model = 0.', 'no'),
    ('t_response_s / t_recovery_s', 'Response and recovery times where stated. Too few to model.', 'no'),
    ('note', 'Anything unusual about the reading.', 'no'),
    ('verified', 'y = re-read from the PDF in the independent check and agrees.', 'no'),
    ('check_note', 'Comment from the independent check.', 'no'),
    ('baseline_offset_pct', 'temperature sheet, 14 Kumar 2018 (Nanotechnology) rows: unrecovered response before the pulse, '
                            'read from thesis Fig. 3.6a/b (approximate).', 'only for dataset temperature_local'),
    ('published_value_local_baseline', '((1 + published_value/100) / (1 + baseline_offset_pct/100) - 1) x 100: the pulse measured '
                                       'from its own starting resistance.', 'only for dataset temperature_local'),
], columns=['column', 'meaning', 'used by the code'])

README = pd.DataFrame([
    ('what this file is', 'Input data of the NO2 sensor ML project: every reading the models use, one row per measured response, '
                          'plus your own sensor\'s values and the list of sources. Built by scripts/build_input_workbook.py from data/raw.'),
    ('sheets', 'humidity: every humidity sweep (35 readings, 8 curves, 6 papers). temperature: every temperature sweep (60 readings, '
               '58 used, 16 curves, 5 papers). your_sensor: your 5 values from the manuscript; row 165 (42.59% at 50 ppm, 520 nm light) '
               'anchors every prediction and is never used for training. sources: the papers. conversions: the five response rules. '
               'columns: what each column means.'),
    ('how to read it in code', 'pandas.read_excel("data/NO2_sensor_data.xlsx", sheet_name="humidity"). Every sheet is one table with its '
                               'header in row 1.'),
    ('unified response', 'Every reading is converted to S (%) = (higher resistance / lower resistance - 1) x 100. For a sensor whose '
                         'resistance rises in NO2 this is the usual (Rg - Ra)/Ra x 100. See the conversions sheet.'),
    ('curves', 'Humidity: one curve = one device_id + series (one figure panel), measured at several RH with everything else fixed. '
               'Temperature: one curve = one device_id at one NO2_ppm, measured at several T_C. A curve needs at least 2 points.'),
    ('analysis choices', 'Which papers to leave out (default: Chen 2021 for humidity), how many rows to interpolate to (default 100) '
                         'and which model to report are settings in the code (no2ml/config.py), so this file stays a plain record '
                         'of the readings.'),
    ('editing', 'If you correct a reading, change Ra, Rg or published_value and update response_pct to match (the code stops '
                'if they disagree), or delete response_pct values and the code will use its own calculation.'),
], columns=['topic', 'description'])

# ---------------------------------------------------------------- write
A = 'Arial'; HDR = PatternFill('solid', fgColor='FF2F4B5C'); GREY = PatternFill('solid', fgColor='FFEDEDED')
thin = Side(style='thin', color='FFBFBFBF'); BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
WIDE_TEXT = {'description', 'meaning', 'reference', 'sensor_and_conditions', 'comment', 'note', 'check_note', 'excluded_because',
             'used_for', 'what was read from the paper', 'formula for response_pct', 'published_definition', 'RH_basis'}
NUMFMT = {'response_pct': '0.000', 'published_value': '0.####', 'published_value_local_baseline': '0.00', 'baseline_offset_pct': '0.00'}


def write_table(wb, name, df, grey_unused=False):
    ws = wb.create_sheet(name)
    cols = list(df.columns)
    for j, c in enumerate(cols, 1):
        cell = ws.cell(1, j, c); cell.font = Font(name=A, size=10, bold=True, color='FFFFFFFF'); cell.fill = HDR
        cell.alignment = Alignment(wrap_text=True, vertical='center'); cell.border = BOX
    for i, rec in enumerate(df.itertuples(index=False), 2):
        unused = grey_unused and getattr(rec, 'use_in_model') != 1
        for j, v in enumerate(rec, 1):
            if isinstance(v, (np.floating, np.integer)): v = v.item()
            if v is pd.NA or (isinstance(v, float) and np.isnan(v)): v = None
            cell = ws.cell(i, j, v); cell.font = Font(name=A, size=10); cell.border = BOX
            cell.alignment = Alignment(vertical='top', wrap_text=cols[j - 1] in WIDE_TEXT)
            if cols[j - 1] in NUMFMT and isinstance(v, float): cell.number_format = NUMFMT[cols[j - 1]]
            if unused: cell.fill = GREY
    for j, c in enumerate(cols, 1):
        width = 60 if c in WIDE_TEXT else min(max(10, len(str(c)) + 2, *(len(str(v)) + 1 for v in df[c].head(60))), 32)
        ws.column_dimensions[openpyxl.utils.get_column_letter(j)].width = width
    ws.freeze_panes = 'B2' if name in ('humidity', 'temperature', 'your_sensor') else 'A2'
    ws.auto_filter.ref = f'A1:{openpyxl.utils.get_column_letter(len(cols))}{len(df) + 1}'
    return ws


wb = openpyxl.Workbook(); wb.remove(wb.active)
write_table(wb, 'README', README)
write_table(wb, 'humidity', sheets['humidity'], grey_unused=True)
write_table(wb, 'temperature', sheets['temperature'], grey_unused=True)
write_table(wb, 'your_sensor', sheets['your_sensor'])
write_table(wb, 'sources', S)
write_table(wb, 'conversions', CONV)
write_table(wb, 'columns', COLS)
wb.save(OUT)

# round trip: the readings the code uses must come back exactly; response_pct is stored to 15 significant digits
# (Excel's precision) and is only used as a cross-check, so it must agree to 1e-12
for name in ('humidity', 'temperature', 'your_sensor'):
    back = pd.read_excel(OUT, sheet_name=name)
    num = [c for c in back.columns if pd.api.types.is_numeric_dtype(back[c])]
    for c in num:
        a, b = back[c].to_numpy(float), sheets[name][c].to_numpy(float)
        if c == 'response_pct': assert np.allclose(a, b, rtol=1e-12, atol=0), (name, c)
        else: assert np.array_equal(a, b, equal_nan=True), (name, c)
print('saved', OUT)
