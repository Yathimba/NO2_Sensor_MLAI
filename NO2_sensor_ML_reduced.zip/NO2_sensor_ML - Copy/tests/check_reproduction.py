"""Check that a run reproduces the stored reference results.

    python run_all.py                     # writes results/
    python tests/check_reproduction.py    # compares results/csv/tables with tests/expected

Exit code 0 = reproduced. Rounded columns must match exactly and other values to 1e-6.
"""
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from no2ml.check import compare

if __name__ == '__main__':
    report, ok = compare(ROOT / 'results' / 'csv' / 'tables', ROOT / 'tests' / 'expected')
    print(report.to_string(index=False))
    print('\nREPRODUCED' if ok else '\nDIFFERENCES FOUND (see above)')
    sys.exit(0 if ok else 1)
